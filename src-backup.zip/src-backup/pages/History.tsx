import React from 'react';
import { motion } from 'framer-motion';
import { Clock, User, Calendar, Shield, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Link } from 'react-router-dom';

const History = () => {
  const activities = [
    { id: 1, user: "Jean Dupont", action: "Inscription", target: "Tech Summit 2024", time: "Il y a 2 min", icon: User, color: "text-blue-500", bg: "bg-blue-50" },
    { id: 2, user: "Marie Curie", action: "Check-in", target: "Atelier IA", time: "Il y a 15 min", icon: Shield, color: "text-emerald-500", bg: "bg-emerald-50" },
    { id: 3, user: "Paul Valéry", action: "Création", target: "Nouvel Événement", time: "Il y a 1h", icon: Calendar, color: "text-violet-500", bg: "bg-violet-50" },
    { id: 4, user: "Sophie Germain", action: "Modification", target: "Profil", time: "Il y a 2h", icon: User, color: "text-amber-500", bg: "bg-amber-50" },
  ];

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-4">
        <Link to="/dashboard">
          <Button variant="ghost" size="icon" className="rounded-full bg-white shadow-sm">
            <ArrowLeft size={20} />
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold">Historique d'activité</h1>
          <p className="text-slate-500">Suivez toutes les actions effectuées sur la plateforme.</p>
        </div>
      </div>

      <Card className="border-none shadow-xl rounded-[2.5rem] overflow-hidden glass">
        <div className="divide-y divide-slate-100">
          {activities.map((activity, i) => (
            <motion.div 
              key={activity.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className="p-6 flex items-center gap-4 hover:bg-slate-50/50 transition-colors"
            >
              <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center shrink-0", activity.bg, activity.color)}>
                <activity.icon size={24} />
              </div>
              <div className="flex-1">
                <p className="font-bold">
                  {activity.user} <span className="font-medium text-slate-500">{activity.action.toLowerCase()}</span> {activity.target}
                </p>
                <div className="flex items-center gap-1 text-xs text-slate-400 mt-1">
                  <Clock size={12} /> {activity.time}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </Card>
    </div>
  );
};

import { cn } from '@/lib/utils';
export default History;