import React from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { QrCode, Download, Share2, Printer } from 'lucide-react';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface BadgeDialogProps {
  isOpen: boolean;
  onClose: () => void;
  eventTitle: string;
  participantName: string;
}

const BadgeDialog = ({ isOpen, onClose, eventTitle, participantName }: BadgeDialogProps) => {
  const handlePrint = () => {
    toast.info("Préparation de l'impression...");
    window.print();
  };

  const handleDownload = () => {
    toast.success("Badge téléchargé au format PDF !");
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success("Lien du badge copié dans le presse-papier !");
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[400px] p-0 overflow-hidden rounded-[3rem] border-none shadow-2xl bg-slate-100">
        <div className="p-8 flex flex-col items-center">
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="w-full aspect-[3/4] bg-white rounded-[2rem] p-8 text-slate-900 flex flex-col items-center justify-between shadow-xl relative overflow-hidden"
          >
            <div className="absolute top-0 left-0 w-full h-3 gradient-primary" />
            
            <div className="w-full flex justify-between items-start">
              <div className="w-10 h-10 gradient-primary rounded-lg flex items-center justify-center text-white font-bold">L</div>
              <Badge className="bg-primary/10 text-primary border-none font-bold">PASS PREMIUM</Badge>
            </div>

            <div className="text-center my-6">
              <div className="w-24 h-24 bg-slate-100 rounded-full mx-auto mb-4 border-4 border-white shadow-lg overflow-hidden">
                <img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200" alt="Avatar" className="w-full h-full object-cover" />
              </div>
              <h4 className="font-black text-2xl uppercase tracking-tight">{participantName}</h4>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">{eventTitle}</p>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
              <QrCode size={120} className="text-slate-900" />
            </div>

            <div className="text-center">
              <p className="text-[10px] text-slate-400 font-bold">ID: #4829-TS24</p>
              <p className="text-[8px] text-slate-300 mt-1">LinQora Verified Digital Badge</p>
            </div>
          </motion.div>

          <div className="grid grid-cols-3 gap-4 mt-8 w-full">
            <Button variant="outline" className="flex-col h-16 rounded-2xl gap-1 bg-white border-none shadow-sm" onClick={handleDownload}>
              <Download size={18} />
              <span className="text-[10px] font-bold">Enregistrer</span>
            </Button>
            <Button variant="outline" className="flex-col h-16 rounded-2xl gap-1 bg-white border-none shadow-sm" onClick={handlePrint}>
              <Printer size={18} />
              <span className="text-[10px] font-bold">Imprimer</span>
            </Button>
            <Button variant="outline" className="flex-col h-16 rounded-2xl gap-1 bg-white border-none shadow-sm" onClick={handleShare}>
              <Share2 size={18} />
              <span className="text-[10px] font-bold">Partager</span>
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default BadgeDialog;