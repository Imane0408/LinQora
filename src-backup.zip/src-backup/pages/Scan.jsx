import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { QrCode, Zap, ShieldCheck, ShieldAlert, History, Keyboard, Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useSelector } from 'react-redux';
import { toast } from 'sonner';
import confetti from 'canvas-confetti';

const Scan = () => {
  const { user } = useSelector((state) => state.auth);
  const [isScanning, setIsScanning] = useState(true);
  const [manualMode, setManualMode] = useState(false);
  const [lastScan, setLastScan] = useState(null);
  const [history, setHistory] = useState([
    { id: '1', name: 'Jean Dupont', time: '14:30', status: 'success', type: 'Pass Premium' },
    { id: '2', name: 'Marie Curie', time: '14:28', status: 'success', type: 'Standard' },
  ]);

  const simulateScan = () => {
    setIsScanning(false);
    const success = Math.random() > 0.1;
    
    if (success) {
      const newScan = { 
        id: Date.now().toString(), 
        name: 'Nouveau Participant', 
        time: new Date().toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'}), 
        status: 'success',
        type: 'Pass VIP'
      };
      setLastScan(newScan);
      setHistory([newScan, ...history]);
      toast.success('Accès Autorisé');
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#4361EE', '#7209B7', '#F72585']
      });
    } else {
      toast.error('Badge Invalide ou Déjà Scanné');
    }

    setTimeout(() => {
      setIsScanning(true);
      setLastScan(null);
    }, 2000);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold">Scanner de Badges</h1>
        <p className="text-slate-500">Scannez le QR code pour valider l'entrée.</p>
      </div>

      <div className="relative aspect-square max-w-md mx-auto">
        <Card className="w-full h-full overflow-hidden border-none shadow-2xl rounded-[3rem] bg-slate-900 flex items-center justify-center relative">
          {isScanning ? (
            <>
              <div className="absolute inset-0 opacity-40 bg-[url('https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=1000')] bg-cover bg-center" />
              
              <motion.div 
                animate={{ top: ['10%', '90%', '10%'] }}
                transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                className="absolute left-0 right-0 h-1 bg-primary shadow-[0_0_15px_rgba(67,97,238,0.8)] z-10"
              />
              
              <div className="relative z-20 flex flex-col items-center gap-4">
                <div className="w-64 h-64 border-2 border-white/30 rounded-3xl flex items-center justify-center">
                  <QrCode size={120} className="text-white/20" />
                </div>
                <p className="text-white font-medium animate-pulse">Alignez le QR code ici</p>
              </div>
            </>
          ) : (
            <AnimatePresence>
              <motion.div 
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="flex flex-col items-center gap-6 text-white z-30"
              >
                <div className="w-24 h-24 rounded-full bg-emerald-500 flex items-center justify-center shadow-lg shadow-emerald-500/40">
                  <ShieldCheck size={48} />
                </div>
                <div className="text-center">
                  <h2 className="text-2xl font-bold">Accès Autorisé</h2>
                  <p className="text-emerald-400 font-semibold">Jean Dupont</p>
                  <p className="text-slate-400 text-sm">Pass Premium • Tech Summit</p>
                </div>
              </motion.div>
            </AnimatePresence>
          )}
        </Card>

        <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 flex gap-4">
          <Button 
            onClick={() => setManualMode(!manualMode)}
            className="rounded-full h-14 px-8 glass border-white/20 text-slate-900 font-bold shadow-xl hover:bg-white"
          >
            <Keyboard className="mr-2" size={20} /> Saisie Manuelle
          </Button>
          <Button 
            onClick={simulateScan}
            className="rounded-full h-14 w-14 btn-primary shadow-xl"
          >
            <Zap size={24} />
          </Button>
        </div>
      </div>

      {manualMode && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="p-6 rounded-3xl border-none shadow-xl glass">
            <div className="flex gap-3">
              <Input placeholder="Entrez l'ID du badge..." className="h-12 rounded-xl" />
              <Button className="btn-primary h-12 rounded-xl px-6">Valider</Button>
            </div>
          </Card>
        </motion.div>
      )}

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold flex items-center gap-2">
            <History size={20} className="text-primary" /> Historique Récent
          </h3>
          <Button variant="ghost" className="text-primary font-bold">Voir tout</Button>
        </div>
        <div className="space-y-3">
          {history.map((item) => (
            <div key={item.id} className="flex items-center justify-between p-4 rounded-2xl bg-white shadow-sm border border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
                  <ShieldCheck size={20} />
                </div>
                <div>
                  <p className="font-bold text-sm">{item.name}</p>
                  <p className="text-xs text-slate-400">{item.time} • {item.type}</p>
                </div>
              </div>
              <Badge className="bg-emerald-50 text-emerald-600 border-emerald-100">Validé</Badge>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Scan;