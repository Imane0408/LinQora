import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { RootState } from '@/store';
import { motion } from 'framer-motion';
import { 
  Calendar, 
  MapPin, 
  Users, 
  QrCode, 
  Settings, 
  ArrowLeft,
  BarChart3,
  Clock,
  Download,
  Share2,
  Edit3,
  Layout,
  Palette,
  Plus,
  CheckCircle2,
  MessageSquare
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import AddSessionDialog from '@/components/events/AddSessionDialog';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const data = [
  { name: '09:00', count: 45 },
  { name: '10:00', count: 120 },
  { name: '11:00', count: 280 },
  { name: '12:00', count: 310 },
  { name: '13:00', count: 350 },
  { name: '14:00', count: 410 },
  { name: '15:00', count: 450 },
];

const pieData = [
  { name: 'Standard', value: 300, color: '#4361EE' },
  { name: 'Premium', value: 120, color: '#7209B7' },
  { name: 'VIP', value: 30, color: '#F72585' },
];

const EventDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { events } = useSelector((state: RootState) => state.events);
  const event = events.find(e => e.id === id);
  
  const [activeTab, setActiveTab] = useState('overview');
  const [isAddSessionOpen, setIsAddSessionOpen] = useState(false);
  const [badgeOrientation, setBadgeOrientation] = useState<'portrait' | 'landscape'>('portrait');
  const [badgeColor, setBadgeColor] = useState('#4361EE');

  if (!event) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold mb-4">Événement non trouvé</h2>
        <Link to="/events">
          <Button className="btn-primary rounded-xl">Retour à la liste</Button>
        </Link>
      </div>
    );
  }

  const handleSaveBadge = () => {
    toast.success("Modèle de badge enregistré avec succès !");
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center gap-4">
        <Link to="/events">
          <Button variant="ghost" size="icon" className="rounded-full bg-white shadow-sm">
            <ArrowLeft size={20} />
          </Button>
        </Link>
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-bold">{event.title}</h1>
            <Badge className={cn(
              "rounded-full px-3 py-1 font-semibold text-white",
              event.status === 'Publié' ? "bg-emerald-500" : 
              event.status === 'Brouillon' ? "bg-slate-500" : "bg-blue-500"
            )}>
              {event.status}
            </Badge>
          </div>
          <p className="text-slate-500 flex items-center gap-2 mt-1">
            <Calendar size={16} /> {new Date(event.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })} • <MapPin size={16} /> {event.location}
          </p>
        </div>
        <div className="md:ml-auto flex gap-3">
          <Link to={event.visibility === 'public' ? `/e/${event.id}` : '#'}>
            <Button variant="outline" className="rounded-xl h-12" onClick={() => event.visibility !== 'public' && toast.warning("Cet événement est privé.")}>
              <Share2 size={18} className="mr-2" /> Voir Landing
            </Button>
          </Link>
          <Button className="btn-primary rounded-xl h-12" onClick={() => toast.info("Mode édition activé")}>
            <Edit3 size={18} className="mr-2" /> Modifier
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
        <TabsList className="bg-slate-100 p-1 rounded-2xl h-14 w-full md:w-auto overflow-x-auto flex-nowrap">
          <TabsTrigger value="overview" className="rounded-xl px-8 font-bold data-[state=active]:gradient-primary data-[state=active]:text-white">Vue d'ensemble</TabsTrigger>
          <TabsTrigger value="analytics" className="rounded-xl px-8 font-bold data-[state=active]:gradient-primary data-[state=active]:text-white">Analyses</TabsTrigger>
          <TabsTrigger value="badge" className="rounded-xl px-8 font-bold data-[state=active]:gradient-primary data-[state=active]:text-white">Design Badge</TabsTrigger>
          <TabsTrigger value="sessions" className="rounded-xl px-8 font-bold data-[state=active]:gradient-primary data-[state=active]:text-white">Programme</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  { label: "Inscriptions", value: event.participants.toString(), total: event.capacity.toString(), color: "text-blue-600" },
                  { label: "Présences", value: Math.floor(event.participants * 0.7).toString(), total: event.participants.toString(), color: "text-emerald-600" },
                  { label: "Networking", value: "42", total: "RDV", color: "text-violet-600" }
                ].map((stat, i) => (
                  <Card key={i} className="border-none shadow-lg rounded-[2rem] p-6 glass">
                    <p className="text-slate-500 text-sm font-bold mb-2 uppercase tracking-wider">{stat.label}</p>
                    <h3 className={`text-4xl font-extrabold ${stat.color}`}>{stat.value}</h3>
                    <p className="text-xs text-slate-400 mt-2">sur {stat.total}</p>
                    <Progress value={(parseInt(stat.value) / (parseInt(stat.total) || 100)) * 100} className="h-1.5 mt-4" />
                  </Card>
                ))}
              </div>

              <Card className="border-none shadow-xl rounded-[2.5rem] p-8 glass">
                <div className="flex justify-between items-center mb-8">
                  <h3 className="text-xl font-bold">Dernières Inscriptions</h3>
                  <Link to="/participants">
                    <Button variant="ghost" className="text-primary font-bold">Voir tout</Button>
                  </Link>
                </div>
                <div className="space-y-4">
                  {[
                    { name: "Alice Martin", time: "2 min", type: "Premium" },
                    { name: "Bob Durand", time: "15 min", type: "Standard" },
                    { name: "Charlie Leroy", time: "1h", type: "VIP" }
                  ].map((user, i) => (
                    <div key={i} className="flex items-center justify-between p-4 rounded-2xl bg-slate-50/50">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-10 w-10 border-2 border-primary/10">
                          <AvatarFallback className="bg-primary/10 text-primary font-bold">{user.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-bold text-sm">{user.name}</p>
                          <p className="text-xs text-slate-500">Inscrit il y a {user.time}</p>
                        </div>
                      </div>
                      <Badge variant="outline" className="rounded-full">{user.type}</Badge>
                    </div>
                  ))}
                </div>
              </Card>
            </div>

            <div className="space-y-8">
              <Card className="border-none shadow-xl rounded-[2.5rem] p-8 glass">
                <h3 className="text-xl font-bold mb-6">Actions Rapides</h3>
                <div className="grid grid-cols-2 gap-4">
                  <Link to="/participants">
                    <Button variant="outline" className="w-full flex flex-col h-24 rounded-2xl gap-2 border-slate-100 hover:border-primary hover:text-primary">
                      <Users size={24} />
                      <span className="text-xs font-bold">Participants</span>
                    </Button>
                  </Link>
                  <Link to="/scan">
                    <Button variant="outline" className="w-full flex flex-col h-24 rounded-2xl gap-2 border-slate-100 hover:border-primary hover:text-primary">
                      <QrCode size={24} />
                      <span className="text-xs font-bold">Scanner</span>
                    </Button>
                  </Link>
                  <Button 
                    variant="outline" 
                    className="flex flex-col h-24 rounded-2xl gap-2 border-slate-100 hover:border-primary hover:text-primary"
                    onClick={() => setActiveTab('analytics')}
                  >
                    <BarChart3 size={24} />
                    <span className="text-xs font-bold">Rapports</span>
                  </Button>
                  <Link to="/history">
                    <Button 
                      variant="outline" 
                      className="w-full flex flex-col h-24 rounded-2xl gap-2 border-slate-100 hover:border-primary hover:text-primary"
                    >
                      <Clock size={24} />
                      <span className="text-xs font-bold">Historique</span>
                    </Button>
                  </Link>
                </div>
              </Card>

              <Card className="border-none shadow-xl rounded-[2.5rem] p-8 gradient-primary text-white">
                <h3 className="text-xl font-bold mb-2">Mode Live</h3>
                <p className="text-white/80 text-sm mb-6">Suivez l'événement en temps réel sur grand écran.</p>
                <Link to={`/live/${event.id}`}>
                  <Button className="w-full bg-white text-primary hover:bg-white/90 rounded-xl font-bold">
                    Lancer le Dashboard Live
                  </Button>
                </Link>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <Card className="lg:col-span-2 border-none shadow-xl rounded-[2.5rem] p-8 glass">
              <CardHeader className="px-0 pt-0">
                <CardTitle className="text-xl font-bold">Courbe des Inscriptions</CardTitle>
              </CardHeader>
              <div className="h-[350px] w-full mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={data}>
                    <defs>
                      <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#4361EE" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#4361EE" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
                    <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                    <Tooltip contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                    <Area type="monotone" dataKey="count" stroke="#4361EE" strokeWidth={3} fillOpacity={1} fill="url(#colorCount)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </Card>

            <Card className="border-none shadow-xl rounded-[2.5rem] p-8 glass">
              <CardHeader className="px-0 pt-0">
                <CardTitle className="text-xl font-bold">Répartition Billets</CardTitle>
              </CardHeader>
              <div className="h-[250px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-3 mt-4">
                {pieData.map((item) => (
                  <div key={item.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                      <span className="text-sm font-medium text-slate-600">{item.name}</span>
                    </div>
                    <span className="text-sm font-bold">{item.value}</span>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="badge">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <Card className="lg:col-span-1 border-none shadow-xl rounded-[2.5rem] p-8 glass">
              <h3 className="text-xl font-bold mb-6">Personnalisation</h3>
              <div className="space-y-6">
                <div className="space-y-3">
                  <label className="text-sm font-bold text-slate-500 uppercase tracking-wider">Mise en page</label>
                  <div className="grid grid-cols-2 gap-3">
                    <Button 
                      variant="outline" 
                      className={cn("h-12 rounded-xl", badgeOrientation === 'portrait' && "border-primary bg-primary/5 text-primary")}
                      onClick={() => setBadgeOrientation('portrait')}
                    >
                      <Layout size={18} className="mr-2" /> Portrait
                    </Button>
                    <Button 
                      variant="outline" 
                      className={cn("h-12 rounded-xl", badgeOrientation === 'landscape' && "border-primary bg-primary/5 text-primary")}
                      onClick={() => setBadgeOrientation('landscape')}
                    >
                      <Layout size={18} className="mr-2 rotate-90" /> Paysage
                    </Button>
                  </div>
                </div>
                <div className="space-y-3">
                  <label className="text-sm font-bold text-slate-500 uppercase tracking-wider">Couleurs</label>
                  <div className="flex flex-wrap gap-3">
                    {['#4361EE', '#7209B7', '#F72585', '#4CC9F0', '#4895EF'].map(color => (
                      <div 
                        key={color} 
                        className={cn(
                          "w-10 h-10 rounded-full cursor-pointer border-2 transition-all",
                          badgeColor === color ? "border-primary scale-110 shadow-md" : "border-white"
                        )} 
                        style={{ backgroundColor: color }}
                        onClick={() => setBadgeColor(color)}
                      />
                    ))}
                    <Button variant="outline" size="icon" className="rounded-full" onClick={() => toast.info("Sélecteur de couleur ouvert")}>
                      <Palette size={18} />
                    </Button>
                  </div>
                </div>
              </div>
              <Button className="w-full mt-8 btn-primary h-12 rounded-xl font-bold" onClick={handleSaveBadge}>
                Enregistrer le modèle
              </Button>
            </Card>

            <div className="lg:col-span-2 flex items-center justify-center bg-slate-100 rounded-[3rem] p-12">
              <motion.div 
                animate={{ 
                  rotate: badgeOrientation === 'landscape' ? 90 : 0,
                  scale: badgeOrientation === 'landscape' ? 0.8 : 1
                }}
                className="w-72 aspect-[3/4] bg-white rounded-2xl p-8 text-slate-900 flex flex-col items-center justify-between shadow-2xl relative overflow-hidden"
              >
                <div className="absolute top-0 left-0 w-full h-2" style={{ backgroundColor: badgeColor }} />
                <div className="w-full flex justify-between items-start">
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold" style={{ backgroundColor: badgeColor }}>L</div>
                  <Badge variant="outline" className="font-bold" style={{ color: badgeColor, borderColor: badgeColor }}>PREMIUM</Badge>
                </div>
                <div className="text-center">
                  <div className="w-24 h-24 bg-slate-100 rounded-full mx-auto mb-4 border-4 border-white shadow-lg overflow-hidden">
                    <img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200" alt="Preview" className="w-full h-full object-cover" />
                  </div>
                  <h4 className="font-black text-2xl uppercase tracking-tight">JEAN DUPONT</h4>
                  <p className="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">{event.title}</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-2xl">
                  <QrCode size={100} className="text-slate-900" />
                </div>
                <p className="text-[10px] text-slate-400 font-bold">ID: #4829-TS24</p>
              </motion.div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="sessions">
          <Card className="border-none shadow-xl rounded-[2.5rem] p-8 glass">
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-xl font-bold">Programme & Sessions</h3>
              <Button onClick={() => setIsAddSessionOpen(true)} className="btn-primary rounded-xl">
                <Plus className="mr-2" size={18} /> Ajouter une session
              </Button>
            </div>
            <div className="space-y-6">
              {event.sessions?.map((session, i) => (
                <div key={i} className="flex gap-6 items-start p-6 rounded-3xl hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-100">
                  <div className="text-primary font-black text-xl whitespace-nowrap">{session.time}</div>
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-1">
                      <h4 className="font-bold text-lg">{session.title}</h4>
                      <Badge variant="secondary" className="text-[10px] font-bold uppercase">Confirmé</Badge>
                    </div>
                    <p className="text-slate-500 text-sm font-medium">{session.room}</p>
                  </div>
                  <Button variant="ghost" size="icon" className="rounded-full" onClick={() => toast.info("Paramètres de session")}><Settings size={18} /></Button>
                </div>
              ))}
              {(!event.sessions || event.sessions.length === 0) && (
                <div className="text-center py-10 text-slate-400">Aucune session programmée.</div>
              )}
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      <AddSessionDialog 
        isOpen={isAddSessionOpen} 
        onClose={() => setIsAddSessionOpen(false)} 
      />
    </div>
  );
};

export default EventDetails;