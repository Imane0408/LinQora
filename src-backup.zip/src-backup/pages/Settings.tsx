import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Building2, 
  Users, 
  Shield, 
  Bell, 
  Globe, 
  Key, 
  CreditCard,
  Plus,
  Mail,
  CheckCircle2,
  ExternalLink,
  Copy,
  RefreshCw,
  Check,
  Trash2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const Settings = () => {
  const [apiKey, setApiKey] = useState("sk_live_51Nz...829");
  const [isPlanOpen, setIsPlanOpen] = useState(false);
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [isEndpointOpen, setIsEndpointOpen] = useState(false);
  const [currentPlan, setCurrentPlan] = useState('Enterprise');

  const handleSave = () => {
    toast.success("Paramètres de l'organisation mis à jour !");
  };

  const handleInvite = () => {
    const email = prompt("Entrez l'adresse email du nouveau membre :");
    if (email) {
      toast.success(`Invitation envoyée à ${email}`);
    }
  };

  const handleCopyKey = () => {
    navigator.clipboard.writeText(apiKey);
    toast.success("Clé API copiée dans le presse-papier !");
  };

  const handleGenerateKey = () => {
    const newKey = "sk_live_" + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    setApiKey(newKey);
    toast.success("Nouvelle clé API générée avec succès !");
  };

  const handleViewInvoice = (date: string) => {
    toast.info(`Téléchargement de la facture du ${date}...`);
  };

  const handleUpdatePlan = (plan: string) => {
    setCurrentPlan(plan);
    setIsPlanOpen(false);
    toast.success(`Votre abonnement a été passé au plan ${plan}.`);
  };

  const handleAddEndpoint = (e: React.FormEvent) => {
    e.preventDefault();
    setIsEndpointOpen(false);
    toast.success("Nouvel endpoint Webhook ajouté !");
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Paramètres</h1>
        <p className="text-slate-500">Gérez votre organisation, votre équipe et vos préférences.</p>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="bg-slate-100 p-1 rounded-2xl h-14 w-full md:w-auto overflow-x-auto flex-nowrap">
          <TabsTrigger value="general" className="rounded-xl px-6 font-bold data-[state=active]:gradient-primary data-[state=active]:text-white">
            <Building2 size={18} className="mr-2" /> Général
          </TabsTrigger>
          <TabsTrigger value="team" className="rounded-xl px-6 font-bold data-[state=active]:gradient-primary data-[state=active]:text-white">
            <Users size={18} className="mr-2" /> Équipe
          </TabsTrigger>
          <TabsTrigger value="billing" className="rounded-xl px-6 font-bold data-[state=active]:gradient-primary data-[state=active]:text-white">
            <CreditCard size={18} className="mr-2" /> Facturation
          </TabsTrigger>
          <TabsTrigger value="api" className="rounded-xl px-6 font-bold data-[state=active]:gradient-primary data-[state=active]:text-white">
            <Key size={18} className="mr-2" /> API & Webhooks
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <Card className="border-none shadow-xl rounded-[2.5rem] p-8 glass">
            <CardHeader className="px-0 pt-0">
              <CardTitle>Profil de l'organisation</CardTitle>
              <CardDescription>Ces informations apparaîtront sur vos factures et pages d'événements.</CardDescription>
            </CardHeader>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
              <div className="space-y-2">
                <Label>Nom de l'entreprise</Label>
                <Input defaultValue="LinQora Tech" className="h-12 rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label>Site Web</Label>
                <Input defaultValue="https://linqora.io" className="h-12 rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label>Email de contact</Label>
                <Input defaultValue="contact@linqora.io" className="h-12 rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label>Fuseau horaire</Label>
                <select className="w-full h-12 rounded-xl border border-slate-200 px-4 outline-none">
                  <option>(GMT+01:00) Paris</option>
                  <option>(GMT+00:00) Londres</option>
                </select>
              </div>
            </div>
            <Button className="btn-primary mt-8 rounded-xl h-12 px-8" onClick={handleSave}>Enregistrer les modifications</Button>
          </Card>

          <Card className="border-none shadow-xl rounded-[2.5rem] p-8 glass">
            <CardHeader className="px-0 pt-0">
              <CardTitle>Notifications</CardTitle>
              <CardDescription>Choisissez comment vous souhaitez être informé.</CardDescription>
            </CardHeader>
            <div className="space-y-6 mt-6">
              {[
                { title: "Nouvelles inscriptions", desc: "Recevoir un email pour chaque nouveau participant." },
                { title: "Rapports quotidiens", desc: "Résumé des activités de la veille chaque matin." },
                { title: "Alertes de sécurité", desc: "Notifications sur les connexions suspectes." }
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div>
                    <p className="font-bold">{item.title}</p>
                    <p className="text-sm text-slate-500">{item.desc}</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="team" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Membres de l'équipe</h2>
            <Button className="btn-primary rounded-xl" onClick={handleInvite}>
              <Plus size={18} className="mr-2" /> Inviter un membre
            </Button>
          </div>
          <Card className="border-none shadow-xl rounded-[2.5rem] overflow-hidden glass">
            <div className="divide-y divide-slate-100">
              {[
                { name: "Jean Dupont", email: "jean@linqora.io", role: "Admin", avatar: "" },
                { name: "Marie Curie", email: "marie@linqora.io", role: "Manager", avatar: "" },
                { name: "Paul Valéry", email: "paul@linqora.io", role: "Scanner", avatar: "" }
              ].map((member, i) => (
                <div key={i} className="p-6 flex items-center justify-between hover:bg-slate-50/50 transition-colors">
                  <div className="flex items-center gap-4">
                    <Avatar className="h-12 w-12 border-2 border-primary/10">
                      <AvatarFallback className="bg-primary/10 text-primary font-bold">{member.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-bold">{member.name}</p>
                      <p className="text-sm text-slate-500">{member.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="px-3 py-1 rounded-full bg-slate-100 text-slate-600 text-xs font-bold">{member.role}</span>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="rounded-full text-slate-400 hover:text-primary"
                      onClick={() => toast.info(`Gestion des permissions pour ${member.name}`)}
                      title="Gérer les permissions"
                    >
                      <Shield size={18} />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="billing" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="border-none shadow-xl rounded-[2.5rem] p-8 glass md:col-span-2">
              <CardHeader className="px-0 pt-0">
                <CardTitle>Plan Actuel</CardTitle>
                <CardDescription>Vous êtes actuellement sur le plan {currentPlan}.</CardDescription>
              </CardHeader>
              <div className="mt-6 p-6 rounded-2xl bg-primary/5 border border-primary/10 flex items-center justify-between">
                <div>
                  <p className="text-2xl font-black text-primary">{currentPlan}</p>
                  <p className="text-sm text-slate-500">Facturation annuelle • Prochain renouvellement : 12 Jan 2025</p>
                </div>
                <Button variant="outline" className="rounded-xl border-primary text-primary" onClick={() => setIsPlanOpen(true)}>Changer de plan</Button>
              </div>
              <div className="mt-8 space-y-4">
                <h4 className="font-bold">Méthode de paiement</h4>
                <div className="flex items-center justify-between p-4 border rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-8 bg-slate-100 rounded flex items-center justify-center font-bold text-[10px]">VISA</div>
                    <p className="font-medium">•••• •••• •••• 4242</p>
                  </div>
                  <Button variant="ghost" className="text-primary font-bold" onClick={() => setIsPaymentOpen(true)}>Modifier</Button>
                </div>
              </div>
            </Card>
            <Card className="border-none shadow-xl rounded-[2.5rem] p-8 glass">
              <CardTitle className="text-lg font-bold mb-6">Dernières Factures</CardTitle>
              <div className="space-y-4">
                {[
                  { date: "01 Mai 2024", amount: "149.00€" },
                  { date: "01 Avr 2024", amount: "149.00€" },
                  { date: "01 Mar 2024", amount: "149.00€" }
                ].map((inv, i) => (
                  <div key={i} className="flex items-center justify-between text-sm">
                    <span className="text-slate-500">{inv.date}</span>
                    <div className="flex items-center gap-2">
                      <span className="font-bold">{inv.amount}</span>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleViewInvoice(inv.date)}><ExternalLink size={14} /></Button>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="api" className="space-y-6">
          <Card className="border-none shadow-xl rounded-[2.5rem] p-8 glass">
            <CardHeader className="px-0 pt-0">
              <CardTitle>Clés API</CardTitle>
              <CardDescription>Utilisez ces clés pour intégrer LinQora à vos propres outils.</CardDescription>
            </CardHeader>
            <div className="mt-6 space-y-6">
              <div className="space-y-2">
                <Label>Clé Secrète (Live)</Label>
                <div className="flex gap-2">
                  <Input value={apiKey} readOnly className="font-mono bg-slate-50 h-12 rounded-xl" />
                  <Button variant="outline" size="icon" className="h-12 w-12 rounded-xl" onClick={handleCopyKey}><Copy size={18} /></Button>
                </div>
              </div>
              <div className="p-4 rounded-xl bg-amber-50 border border-amber-100 text-amber-700 text-sm">
                Ne partagez jamais vos clés API secrètes. Si une clé est compromise, réinitialisez-la immédiatement.
              </div>
              <Button className="btn-primary rounded-xl h-12 px-8" onClick={handleGenerateKey}>Générer une nouvelle clé</Button>
            </div>
          </Card>

          <Card className="border-none shadow-xl rounded-[2.5rem] p-8 glass">
            <CardHeader className="px-0 pt-0">
              <CardTitle>Webhooks</CardTitle>
              <CardDescription>Recevez des notifications en temps réel sur votre serveur.</CardDescription>
            </CardHeader>
            <div className="mt-6 text-center py-10 border-2 border-dashed rounded-2xl border-slate-100">
              <p className="text-slate-400 mb-4">Aucun webhook configuré.</p>
              <Button variant="outline" className="rounded-xl h-12 px-8" onClick={() => setIsEndpointOpen(true)}>Ajouter un endpoint</Button>
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Modale de changement de plan */}
      <Dialog open={isPlanOpen} onOpenChange={setIsPlanOpen}>
        <DialogContent className="rounded-[2rem] p-8 sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">Changer de forfait</DialogTitle>
            <DialogDescription>Choisissez l'offre qui correspond le mieux à vos besoins.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            {['Starter', 'Pro', 'Enterprise'].map((p) => (
              <div 
                key={p} 
                onClick={() => handleUpdatePlan(p)} 
                className={cn(
                  "p-5 rounded-2xl border-2 cursor-pointer flex justify-between items-center transition-all",
                  currentPlan === p ? "border-primary bg-primary/5" : "border-slate-100 hover:border-slate-200"
                )}
              >
                <div>
                  <p className="font-bold text-lg">{p}</p>
                  <p className="text-sm text-slate-500">{p === 'Enterprise' ? 'Sur mesure' : p === 'Pro' ? '149€/évt' : 'Gratuit'}</p>
                </div>
                {currentPlan === p && <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center text-white"><Check size={14} /></div>}
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Modale de modification de paiement */}
      <Dialog open={isPaymentOpen} onOpenChange={setIsPaymentOpen}>
        <DialogContent className="rounded-[2rem] p-8 sm:max-w-[450px]">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">Méthode de paiement</DialogTitle>
            <DialogDescription>Mettez à jour vos informations de facturation.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Numéro de carte</Label>
              <Input placeholder="4242 4242 4242 4242" className="h-12 rounded-xl" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Expiration</Label>
                <Input placeholder="MM/YY" className="h-12 rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label>CVC</Label>
                <Input placeholder="123" className="h-12 rounded-xl" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button className="btn-primary w-full h-12 rounded-xl font-bold" onClick={() => { setIsPaymentOpen(false); toast.success("Carte mise à jour !"); }}>Enregistrer la carte</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modale d'ajout d'endpoint Webhook */}
      <Dialog open={isEndpointOpen} onOpenChange={setIsEndpointOpen}>
        <DialogContent className="rounded-[2rem] p-8 sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">Ajouter un Webhook</DialogTitle>
            <DialogDescription>Configurez une URL pour recevoir les événements en temps réel.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAddEndpoint} className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>URL de l'endpoint</Label>
              <Input placeholder="https://votre-api.com/webhook" className="h-12 rounded-xl" required />
            </div>
            <div className="space-y-2">
              <Label>Événements à écouter</Label>
              <div className="grid grid-cols-2 gap-2">
                {['participant.created', 'event.published', 'scan.success', 'meeting.requested'].map(ev => (
                  <div key={ev} className="flex items-center gap-2 p-2 rounded-lg bg-slate-50">
                    <input type="checkbox" className="rounded border-slate-300" defaultChecked />
                    <span className="text-xs font-mono">{ev}</span>
                  </div>
                ))}
              </div>
            </div>
            <DialogFooter className="pt-4">
              <Button type="submit" className="btn-primary w-full h-12 rounded-xl font-bold">Créer l'endpoint</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Settings;