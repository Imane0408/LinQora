import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Mail, Send, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

const schema = z.object({
  to: z.string().email("Email invalide"),
  subject: z.string().min(3, "Le sujet est trop court"),
  message: z.string().min(10, "Le message est trop court"),
});

interface EmailDialogProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTo?: string;
}

const EmailDialog = ({ isOpen, onClose, defaultTo }: EmailDialogProps) => {
  const { register, handleSubmit, formState: { errors, isSubmitting }, reset } = useForm({
    resolver: zodResolver(schema),
    defaultValues: { to: defaultTo || '', subject: '', message: '' }
  });

  const onSubmit = async (data: any) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    toast.success(`Email envoyé à ${data.to} (Simulation)`);
    reset();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] rounded-[2.5rem] border-none shadow-2xl p-8">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold flex items-center gap-2">
            <Mail className="text-primary" /> Envoyer un email
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Destinataire</Label>
            <Input {...register('to')} className={cn("h-12 rounded-xl", errors.to && "border-red-500")} />
            {errors.to && <p className="text-xs text-red-500">{errors.to.message as string}</p>}
          </div>
          <div className="space-y-2">
            <Label>Sujet</Label>
            <Input {...register('subject')} placeholder="Ex: Votre badge pour l'événement" className={cn("h-12 rounded-xl", errors.subject && "border-red-500")} />
            {errors.subject && <p className="text-xs text-red-500">{errors.subject.message as string}</p>}
          </div>
          <div className="space-y-2">
            <Label>Message</Label>
            <Textarea {...register('message')} className={cn("min-h-[150px] rounded-xl", errors.message && "border-red-500")} />
            {errors.message && <p className="text-xs text-red-500">{errors.message.message as string}</p>}
          </div>
          <DialogFooter className="pt-4">
            <Button type="button" variant="ghost" onClick={onClose} className="rounded-xl h-12 font-bold">Annuler</Button>
            <Button type="submit" disabled={isSubmitting} className="btn-primary flex-1 rounded-xl h-12 font-bold">
              {isSubmitting ? <Loader2 className="animate-spin mr-2" /> : <Send className="mr-2" size={18} />}
              Envoyer
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

import { cn } from '@/lib/utils';
export default EmailDialog;