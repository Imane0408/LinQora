import * as React from "react"
import * as SheetPrimitive from "@radix-ui/react-dialog"
import { cva } from "class-variance-authority"
import { cn } from "@/lib/utils"

const sheetVariants = cva(
  "relative inline-flex w-full rounded-lg border-none bg-transparent p-4 shadow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=transitioning]:transition ease-out duration-150",
  {
    variants: {
      content: {
        "bg-white": "bg-white dark:bg-dark",
        "bg-primary": "bg-primary dark:bg-primary",
      },
      mounted: {
        "scale-y-100": "scale-y-100 opacity-100",
        "scale-y-95": "scale-y-95 opacity-0",
      },
      transition: {
        "enter": "transition ease-out duration-150",
        "enter-from": "scale-y-95 opacity-0",
        "enter-to": "scale-y-100 opacity-100",
        "leave": "transition ease-in duration-150",
        "leave-from": "scale-y-100 opacity-100",
        "leave-to": "scale-y-95 opacity-0",
      },
    },
    defaultVariants: {
      content: "bg-white",
      mounted: "scale-y-100 opacity-100",
      transition: "enter",
    },
  }
)

const Sheet = React.forwardRef(
  ({ className, ...props }, ref) => {
    return (
      <SheetPrimitive.Root
        ref={ref}
        className={cn("relative z-50 bg-white dark:bg-dark border border-slate-200 dark:border-slate-800 rounded-lg shadow-lg", className)}
        {...props}
      />
    )
  }
)

const SheetTrigger = React.forwardRef(
  ({ className, ...props }, ref) => {
    return (
      <SheetPrimitive.Trigger
        ref={ref}
        className={cn(
          "w-full rounded-md px-3 py-2 text-sm font-medium text-primary hover:bg-primary/50 focus:outline-none focus:ring-2 focus:ring-primary/50",
          className
        )}
        {...props}
      />
    )
  }
)

const SheetContent = React.forwardRef(
  ({ className, ...props }, ref) => {
    return (
      <SheetPrimitive.Content
        ref={ref}
        className={cn(
          "w-full rounded-t-lg bg-white dark:bg-dark border-b border-slate-200 dark:border-slate-800 p-4 shadow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50",
          className
        )}
        {...props}
      />
    )
  }
)

export { Sheet, SheetTrigger, SheetContent, sheetVariants }