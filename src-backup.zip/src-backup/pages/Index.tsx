import React, { useState } from 'react';
import Navbar from '@/components/layout/Navbar';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import { 
  Calendar, 
  Users, 
  QrCode, 
  Zap, 
  Shield, 
  BarChart3, 
  Check, 
  ArrowRight,
  Globe,
  Smartphone,
  MessageSquare
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import DemoModal from '@/components/modals/DemoModal';

const Index = () => {
  const navigate = useNavigate();
  const [isDemoModalOpen, setIsDemoModalOpen] = useState(false);

  const handlePlanSelection = (planName: string) => {
    toast.success(`Plan ${planName} sélectionné !`);
    navigate('/register');
  };

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-40 pb-20 px-4 overflow-hidden">
        <div className="container mx-auto text-center relative">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl -z-10" />
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl md:text-7xl font-extrabold mb-6 leading-tight">
              L'expérience événementielle <br />
              <span className="text-gradient">réinventée</span>
            </h1>
            <p className="text-xl text-slate-600 max-w-2xl mx-auto mb-10">
              LinQora est la plateforme tout-en-un pour les organisateurs exigeants. Gérez vos inscriptions, scans et networking en toute simplicité.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/register">
                <Button className="btn-primary text-lg px-10 py-7 rounded-2xl">Démarrer gratuitement</Button>
              </Link>
              <Button 
                variant="outline" 
                className="text-lg px-10 py-7 rounded-2xl border-2 bg-white"
                onClick={() => setIsDemoModalOpen(true)}
              >
                Réserver une démo
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* How it Works */}
      <section className="py-24 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Comment ça marche ?</h2>
            <p className="text-slate-500">Trois étapes simples pour un événement réussi.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { step: "01", title: "Créez votre événement", desc: "Configurez votre landing page et vos types de billets en quelques minutes.", icon: Calendar },
              { step: "02", title: "Invitez vos participants", desc: "Diffusez votre lien d'inscription et gérez les confirmations automatiquement.", icon: Users },
              { step: "03", title: "Pilotez le jour J", desc: "Scannez les badges et facilitez le networking entre vos invités.", icon: Zap }
            ].map((item, i) => (
              <div key={i} className="relative group">
                <div className="w-20 h-20 gradient-primary rounded-3xl flex items-center justify-center text-white mb-8 shadow-xl group-hover:scale-110 transition-transform">
                  <item.icon size={32} />
                </div>
                <span className="text-6xl font-black text-slate-200 absolute top-0 right-0 -z-0 opacity-50">{item.step}</span>
                <h3 className="text-2xl font-bold mb-4 relative z-10">{item.title}</h3>
                <p className="text-slate-600 leading-relaxed relative z-10">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Fonctionnalités Clés</h2>
            <p className="text-slate-500">Tout ce dont vous avez besoin pour briller.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: QrCode, title: "Scan QR Ultra-rapide", desc: "Interface optimisée pour les gros flux de participants." },
              { icon: MessageSquare, title: "Networking IA", desc: "Mise en relation intelligente basée sur les intérêts." },
              { icon: BarChart3, title: "Analytics Avancés", desc: "Suivez l'engagement et les présences en temps réel." },
              { icon: Shield, title: "Sécurité Totale", desc: "Données chiffrées et conformité RGPD garantie." },
              { icon: Smartphone, title: "App Mobile Staff", desc: "Une application dédiée pour vos équipes sur le terrain." },
              { icon: Globe, title: "Multi-langues", desc: "Gérez des événements internationaux sans barrière." }
            ].map((feature, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -5 }}
                className="p-8 rounded-3xl border bg-white card-hover"
              >
                <div className="w-14 h-14 gradient-primary rounded-2xl flex items-center justify-center text-white mb-6">
                  <feature.icon size={28} />
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-slate-600 leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-24 bg-slate-900 text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Tarifs simples et transparents</h2>
            <p className="text-slate-400">Choisissez le plan qui correspond à vos besoins.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {[
              { name: "Starter", price: "0€", desc: "Pour vos petits événements", features: ["Jusqu'à 50 participants", "Scan QR basique", "Landing page standard"] },
              { name: "Pro", price: "149€", desc: "Le choix des professionnels", features: ["Participants illimités", "Networking IA", "Stats avancées", "Support prioritaire"], popular: true },
              { name: "Enterprise", price: "Sur devis", desc: "Pour les grands comptes", features: ["Marque blanche", "API & Webhooks", "Account Manager dédié", "SLA 99.9%"] }
            ].map((plan, i) => (
              <div key={i} className={cn(
                "p-10 rounded-[2.5rem] border flex flex-col",
                plan.popular ? "bg-white text-slate-900 border-primary scale-105 shadow-2xl" : "bg-slate-800/50 border-slate-700"
              )}>
                {plan.popular && <span className="bg-primary text-white text-xs font-bold px-4 py-1 rounded-full self-start mb-4">PLUS POPULAIRE</span>}
                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <div className="flex items-baseline gap-1 mb-4">
                  <span className="text-4xl font-black">{plan.price}</span>
                  {plan.price !== "Sur devis" && <span className="text-slate-500">/événement</span>}
                </div>
                <p className={cn("mb-8", plan.popular ? "text-slate-600" : "text-slate-400")}>{plan.desc}</p>
                <div className="space-y-4 mb-10 flex-1">
                  {plan.features.map((f, j) => (
                    <div key={j} className="flex items-center gap-3">
                      <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                        <Check size={12} />
                      </div>
                      <span className="text-sm font-medium">{f}</span>
                    </div>
                  ))}
                </div>
                <Button 
                  className={cn(
                    "w-full h-14 rounded-xl font-bold text-lg",
                    plan.popular ? "btn-primary" : "bg-slate-700 hover:bg-slate-600 text-white"
                  )}
                  onClick={() => handlePlanSelection(plan.name)}
                >
                  Choisir ce plan
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
            <div className="col-span-1 md:col-span-1">
              <Link to="/" className="flex items-center gap-2 mb-6">
                <div className="w-10 h-10 gradient-primary rounded-xl flex items-center justify-center text-white font-bold text-xl">L</div>
                <span className="text-2xl font-bold text-gradient">LinQora</span>
              </Link>
              <p className="text-slate-500 leading-relaxed">
                La plateforme de gestion d'événements nouvelle génération pour des expériences mémorables.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-6">Produit</h4>
              <ul className="space-y-4 text-slate-500">
                <li><a href="#" className="hover:text-primary transition-colors">Fonctionnalités</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Tarifs</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">API</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Sécurité</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-6">Entreprise</h4>
              <ul className="space-y-4 text-slate-500">
                <li><a href="#" className="hover:text-primary transition-colors">À propos</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Carrières</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-6">Légal</h4>
              <ul className="space-y-4 text-slate-500">
                <li><a href="#" className="hover:text-primary transition-colors">Confidentialité</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">CGU</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Mentions légales</a></li>
              </ul>
            </div>
          </div>
          <div className="pt-8 border-t flex flex-col md:flex-row justify-between items-center gap-4 text-slate-400 text-sm">
            <p>© 2024 LinQora. Tous droits réservés.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-primary transition-colors">Twitter</a>
              <a href="#" className="hover:text-primary transition-colors">LinkedIn</a>
              <a href="#" className="hover:text-primary transition-colors">Instagram</a>
            </div>
          </div>
        </div>
      </footer>

      <DemoModal isOpen={isDemoModalOpen} onClose={() => setIsDemoModalOpen(false)} />
    </div>
  );
};

export default Index;