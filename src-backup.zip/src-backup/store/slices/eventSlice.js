import { createSlice } from '@reduxjs/toolkit';

const eventSlice = createSlice({
  name: 'events',
  initialState: {
    events: [],
  },
  reducers: {
    addEvent: (state, action) => {
      state.events.unshift(action.payload);
      localStorage.setItem('linqora_events', JSON.stringify(state.events));
    },
    updateEvent: (state, action) => {
      const index = state.events.findIndex(e => e.id === action.payload.id);
      if (index !== -1) {
        state.events[index] = action.payload;
        localStorage.setItem('linqora_events', JSON.stringify(state.events));
      }
    },
    deleteEvent: (state, action) => {
      state.events = state.events.filter(e => e.id !== action.payload);
      localStorage.setItem('linqora_events', JSON.stringify(state.events));
    },
    addSession: (state, action) => {
      const event = state.events.find(e => e.id === action.payload.eventId);
      if (event) {
        if (!event.sessions) event.sessions = [];
        event.sessions.push(action.payload.session);
        localStorage.setItem('linqora_events', JSON.stringify(state.events));
      }
    },
    updateSession: (state, action) => {
      const event = state.events.find(e => e.id === action.payload.eventId);
      if (event && event.sessions) {
        const sIndex = event.sessions.findIndex(s => s.id === action.payload.session.id);
        if (sIndex !== -1) {
          event.sessions[sIndex] = action.payload.session;
          localStorage.setItem('linqora_events', JSON.stringify(state.events));
        }
      }
    },
    deleteSession: (state, action) => {
      const event = state.events.find(e => e.id === action.payload.eventId);
      if (event && event.sessions) {
        event.sessions = event.sessions.filter(s => s.id !== action.payload.sessionId);
        localStorage.setItem('linqora_events', JSON.stringify(state.events));
      }
    }
  },
});

export const { addEvent, updateEvent, deleteEvent, addSession, updateSession, deleteSession } = eventSlice.actions;
export default eventSlice.reducer;