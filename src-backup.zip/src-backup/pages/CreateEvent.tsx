import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Calendar, 
  MapPin, 
  Users, 
  Check, 
  ArrowRight, 
  ArrowLeft,
  Upload,
  Plus,
  Trash2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { addEvent } from '@/store/slices/eventSlice';
import { cn } from '@/lib/utils';

const steps = [
  { id: 1, title: 'Infos Générales', icon: Calendar },
  { id: 2, title: 'Configuration', icon: Users },
  { id: 3, title: 'Ateliers & Speakers', icon: Plus },
  { id: 4, title: 'Publication', icon: Check },
];

const CreateEvent = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    date: '',
    location: '',
    capacity: '500',
    type: 'Présentiel' as const,
    visibility: 'public' as const,
    image: 'https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?auto=format&fit=crop&q=80&w=1000'
  });

  const [sessions, setSessions] = useState([
    { id: 1, title: "Session d'ouverture", time: "09:00 - 10:00", room: "Main Hall" }
  ]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, image: reader.result as string });
        toast.success("Image mise à jour !");
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFinalize = (status: 'Publié' | 'Brouillon') => {
    const newEvent = {
      id: Math.random().toString(36).substr(2, 9),
      ...formData,
      participants: 0,
      capacity: parseInt(formData.capacity),
      status: status,
      sessions: sessions,
      type: formData.type as any
    };

    dispatch(addEvent(newEvent));
    toast.success(status === 'Publié' ? 'Événement publié !' : 'Brouillon enregistré');
    navigate('/events');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex items-center justify-between mb-12">
        {steps.map((step) => (
          <div key={step.id} className="flex flex-col items-center relative flex-1">
            <div className={cn(
              "w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-300 z-10",
              currentStep >= step.id ? "gradient-primary text-white shadow-lg" : "bg-slate-100 text-slate-400"
            )}>
              <step.icon size={24} />
            </div>
            <span className={cn(
              "mt-3 text-sm font-bold",
              currentStep >= step.id ? "text-primary" : "text-slate-400"
            )}>
              {step.title}
            </span>
            {step.id < steps.length && (
              <div className={cn(
                "absolute top-6 left-1/2 w-full h-[2px] -z-0",
                currentStep > step.id ? "bg-primary" : "bg-slate-100"
              )} />
            )}
          </div>
        ))}
      </div>

      <Card className="border-none shadow-2xl rounded-[2.5rem] p-10 glass">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-8"
          >
            {currentStep === 1 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold">Informations Générales</h2>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Titre</Label>
                    <Input 
                      value={formData.title}
                      onChange={(e) => setFormData({...formData, title: e.target.value})}
                      placeholder="Ex: Tech Summit 2024" 
                      className="h-12 rounded-xl" 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Textarea 
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                      placeholder="Décrivez votre événement..." 
                      className="min-h-[120px] rounded-xl" 
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Date</Label>
                      <Input 
                        type="datetime-local" 
                        value={formData.date}
                        onChange={(e) => setFormData({...formData, date: e.target.value})}
                        className="h-12 rounded-xl" 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Lieu</Label>
                      <Input 
                        value={formData.location}
                        onChange={(e) => setFormData({...formData, location: e.target.value})}
                        placeholder="Paris, France" 
                        className="h-12 rounded-xl" 
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Bannière</Label>
                    <div 
                      onClick={() => fileInputRef.current?.click()}
                      className="border-2 border-dashed border-slate-200 rounded-2xl p-8 text-center hover:border-primary cursor-pointer transition-all"
                    >
                      <Upload className="mx-auto text-slate-400 mb-2" size={32} />
                      <p className="text-sm text-slate-500">Changer l'image de couverture</p>
                      <input type="file" ref={fileInputRef} className="hidden" onChange={handleImageUpload} />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold">Configuration</h2>
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label>Type</Label>
                    <select 
                      className="w-full h-12 rounded-xl border border-slate-200 px-4"
                      value={formData.type}
                      onChange={(e) => setFormData({...formData, type: e.target.value as any})}
                    >
                      <option>Présentiel</option>
                      <option>Hybride</option>
                      <option>Virtuel</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label>Capacité</Label>
                    <Input 
                      type="number" 
                      value={formData.capacity}
                      onChange={(e) => setFormData({...formData, capacity: e.target.value})}
                      className="h-12 rounded-xl" 
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Visibilité</Label>
                  <div className="flex gap-4">
                    <Button 
                      variant="outline" 
                      className={cn("flex-1 h-12 rounded-xl", formData.visibility === 'public' && "border-primary text-primary bg-primary/5")}
                      onClick={() => setFormData({...formData, visibility: 'public'})}
                    >
                      Public
                    </Button>
                    <Button 
                      variant="outline" 
                      className={cn("flex-1 h-12 rounded-xl", formData.visibility === 'private' && "border-primary text-primary bg-primary/5")}
                      onClick={() => setFormData({...formData, visibility: 'private'})}
                    >
                      Privé
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold">Programme</h2>
                  <Button variant="outline" className="rounded-xl" onClick={() => setSessions([...sessions, { id: Date.now(), title: "Nouvelle Session", time: "10:00 - 11:00", room: "Salle B" }])}>
                    <Plus size={18} className="mr-2" /> Ajouter
                  </Button>
                </div>
                <div className="space-y-4">
                  {sessions.map((s) => (
                    <div key={s.id} className="p-4 rounded-xl border border-slate-100 bg-slate-50 flex justify-between items-center">
                      <div>
                        <p className="font-bold">{s.title}</p>
                        <p className="text-xs text-slate-500">{s.time} • {s.room}</p>
                      </div>
                      <Button variant="ghost" size="icon" className="text-red-500" onClick={() => setSessions(sessions.filter(item => item.id !== s.id))}>
                        <Trash2 size={18} />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {currentStep === 4 && (
              <div className="text-center space-y-6 py-10">
                <div className="w-20 h-20 gradient-primary rounded-full flex items-center justify-center text-white mx-auto shadow-xl">
                  <Check size={40} />
                </div>
                <h2 className="text-3xl font-bold">Prêt à lancer ?</h2>
                <p className="text-slate-500">Vérifiez vos informations avant de publier.</p>
                <div className="flex flex-col gap-3 max-w-xs mx-auto">
                  <Button onClick={() => handleFinalize('Publié')} className="btn-primary h-14 rounded-xl text-lg font-bold">Publier maintenant</Button>
                  <Button onClick={() => handleFinalize('Brouillon')} variant="outline" className="h-14 rounded-xl font-bold">Enregistrer brouillon</Button>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>

        <div className="flex justify-between mt-12 pt-8 border-t border-slate-100">
          <Button variant="ghost" onClick={() => setCurrentStep(currentStep - 1)} disabled={currentStep === 1} className="h-12 px-6 rounded-xl font-bold">
            <ArrowLeft className="mr-2" size={20} /> Précédent
          </Button>
          {currentStep < 4 && (
            <Button onClick={() => setCurrentStep(currentStep + 1)} className="btn-primary h-12 px-8 rounded-xl font-bold">
              Suivant <ArrowRight className="ml-2" size={20} />
            </Button>
          )}
        </div>
      </Card>
    </div>
  );
};

export default CreateEvent;