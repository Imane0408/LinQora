import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { motion } from 'framer-motion';
import { Building2, Mail, Lock, ArrowRight, User } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const Register = () => {
  const [step, setStep] = useState(1);
  const navigate = useNavigate();

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 1) {
      setStep(2);
    } else {
      toast.success('Compte entreprise créé ! Bienvenue sur LinQora.');
      navigate('/login');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-[#F8F9FA]">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md glass p-10 rounded-[2rem] shadow-2xl"
      >
        <div className="text-center mb-10">
          <div className="w-16 h-16 gradient-primary rounded-2xl flex items-center justify-center text-white font-bold text-3xl mx-auto mb-6 shadow-lg">L</div>
          <h1 className="text-3xl font-bold mb-2">Créer un compte</h1>
          <p className="text-slate-500">Lancez votre premier événement en quelques minutes</p>
        </div>

        <div className="flex gap-2 mb-8">
          <div className={cn("h-1 flex-1 rounded-full transition-colors", step >= 1 ? "bg-primary" : "bg-slate-200")} />
          <div className={cn("h-1 flex-1 rounded-full transition-colors", step >= 2 ? "bg-primary" : "bg-slate-200")} />
        </div>

        <form onSubmit={handleRegister} className="space-y-6">
          {step === 1 ? (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-6"
            >
              <div className="space-y-2">
                <Label htmlFor="company">Nom de l'entreprise</Label>
                <div className="relative">
                  <Building2 className="absolute left-3 top-3 text-slate-400" size={20} />
                  <Input id="company" placeholder="LinQora Tech" className="pl-10 h-12 rounded-xl" required />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email professionnel</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 text-slate-400" size={20} />
                  <Input id="email" type="email" placeholder="contact@entreprise.com" className="pl-10 h-12 rounded-xl" required />
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-6"
            >
              <div className="space-y-2">
                <Label htmlFor="admin">Nom de l'administrateur</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 text-slate-400" size={20} />
                  <Input id="admin" placeholder="Jean Dupont" className="pl-10 h-12 rounded-xl" required />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Mot de passe</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 text-slate-400" size={20} />
                  <Input id="password" type="password" placeholder="••••••••" className="pl-10 h-12 rounded-xl" required />
                </div>
              </div>
            </motion.div>
          )}

          <Button type="submit" className="w-full btn-primary h-14 rounded-xl text-lg font-bold group">
            {step === 1 ? 'Continuer' : 'Créer mon compte'}
            <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
          </Button>
        </form>

        <p className="text-center mt-8 text-slate-600">
          Déjà un compte ?{' '}
          <Link to="/login" className="text-primary font-bold hover:underline">Se connecter</Link>
        </p>
      </motion.div>
    </div>
  );
};

export default Register;