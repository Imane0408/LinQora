import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, Filter, Download, Mail, MoreVertical, CheckCircle2, XCircle, Clock, UserCheck, Trash2, Edit2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Card } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import confetti from 'canvas-confetti';
import ConfirmDialog from '@/components/modals/ConfirmDialog';
import EmailDialog from '@/components/modals/EmailDialog';
import { exportToCSV } from '@/utils/export';

const initialParticipants = [
  { id: '1', name: 'Alice Martin', email: 'alice@tech.com', org: 'Tech Corp', event: 'Tech Summit', status: 'Présent', role: 'Participant' },
  { id: '2', name: 'Bob Durand', email: 'bob@innov.fr', org: 'Innov SAS', event: 'Atelier IA', status: 'En attente', role: 'Speaker' },
  { id: '3', name: 'Charlie Leroy', email: 'charlie@web.io', org: 'Web Studio', event: 'Tech Summit', status: 'Absent', role: 'Participant' },
  { id: '4', name: 'Diane Petit', email: 'diane@data.com', org: 'Data Solutions', event: 'Networking', status: 'Présent', role: 'VIP' },
];

const Participants = () => {
  const [data, setData] = useState(() => {
    const saved = localStorage.getItem('linqora_participants');
    return saved ? JSON.parse(saved) : initialParticipants;
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [isEmailOpen, setIsEmailOpen] = useState(false);
  const [selectedParticipant, setSelectedParticipant] = useState<any>(null);

  useEffect(() => {
    localStorage.setItem('linqora_participants', JSON.stringify(data));
  }, [data]);

  const filteredParticipants = data.filter((p: any) => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.org.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCheckIn = (id: string, name: string) => {
    setData(data.map((p: any) => p.id === id ? { ...p, status: 'Présent' } : p));
    toast.success(`${name} a été enregistré !`);
    confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
  };

  const handleDelete = () => {
    setData(data.filter((p: any) => p.id !== selectedParticipant.id));
    toast.error(`Participant supprimé`);
    setIsConfirmOpen(false);
  };

  const handleExport = () => {
    exportToCSV(data, 'participants_linqora');
    toast.success("Exportation réussie !");
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Participants</h1>
          <p className="text-slate-500">Gérez les inscriptions et suivez les présences.</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="rounded-xl h-12" onClick={handleExport}>
            <Download className="mr-2" size={18} /> Exporter
          </Button>
          <Button className="btn-primary rounded-xl h-12" onClick={() => setIsEmailOpen(true)}>
            <Mail className="mr-2" size={18} /> Envoyer un email
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <Input 
            placeholder="Rechercher..." 
            className="pl-10 h-12 rounded-xl border-slate-200"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <Card className="border-none shadow-xl rounded-[2rem] overflow-hidden glass">
        <Table>
          <TableHeader className="bg-slate-50/50">
            <TableRow className="border-slate-100">
              <TableHead className="font-bold py-6 pl-8">Participant</TableHead>
              <TableHead className="font-bold">Organisation</TableHead>
              <TableHead className="font-bold">Statut</TableHead>
              <TableHead className="font-bold text-right pr-8">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredParticipants.map((p: any) => (
              <TableRow key={p.id} className="border-slate-50 hover:bg-slate-50/30 transition-colors">
                <TableCell className="py-4 pl-8">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10 border-2 border-primary/10">
                      <AvatarFallback className="bg-primary/10 text-primary font-bold">{p.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-bold">{p.name}</p>
                      <p className="text-xs text-slate-500">{p.email}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell className="font-medium">{p.org}</TableCell>
                <TableCell>
                  <Badge className={cn(
                    "rounded-full",
                    p.status === 'Présent' ? "bg-emerald-500" : p.status === 'Absent' ? "bg-red-500" : "bg-amber-500"
                  )}>{p.status}</Badge>
                </TableCell>
                <TableCell className="text-right pr-8">
                  <div className="flex justify-end gap-2">
                    {p.status !== 'Présent' && (
                      <Button size="sm" variant="outline" className="rounded-lg" onClick={() => handleCheckIn(p.id, p.name)}>Check-in</Button>
                    )}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon"><MoreVertical size={18} /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="rounded-xl">
                        <DropdownMenuItem onClick={() => { setSelectedParticipant(p); setIsEmailOpen(true); }}>Email</DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600" onClick={() => { setSelectedParticipant(p); setIsConfirmOpen(true); }}>Supprimer</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      <ConfirmDialog 
        isOpen={isConfirmOpen} 
        onClose={() => setIsConfirmOpen(false)} 
        onConfirm={handleDelete}
        title="Supprimer le participant ?"
        description={`Êtes-vous sûr de vouloir retirer ${selectedParticipant?.name} de la liste ?`}
      />

      <EmailDialog 
        isOpen={isEmailOpen} 
        onClose={() => setIsEmailOpen(false)} 
        defaultTo={selectedParticipant?.email}
      />
    </div>
  );
};

export default Participants;