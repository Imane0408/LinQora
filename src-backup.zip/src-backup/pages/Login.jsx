import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { setCredentials } from '@/store/slices/authSlice';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { motion } from 'framer-motion';
import { Mail, Lock, ArrowRight, ShieldAlert, Building2, ShieldCheck, QrCode, Users } from 'lucide-react';
import { toast } from 'sonner';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handleLogin = (e, customRole) => {
    if (e) e.preventDefault();

    const names = {
      SUPER_ADMIN: 'Super Administrateur',
      COMPANY_ADMIN: 'Admin LinQora Tech',
      EVENT_MANAGER: 'Manager Événement',
      SCAN_OPERATOR: 'Opérateur Scan',
      PARTICIPANT: 'Jean Participant',
      SPEAKER: 'Speaker Expert'
    };

    const role = customRole || ['EVENT_MANAGER'];
    const name = role.map(r => names[r]).join(' / ');

    dispatch(setCredentials({
      user: {
        id: '1',
        name: name,
        email: email || 'demo@linqora.io',
        role: role
      },
      token: 'fake-jwt-token'
    }));

    toast.success(`Connecté en tant que ${role.map(r => r.replace('_', ' ')).join(' / ')}`);
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-[#F8F9FA]">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md glass p-10 rounded-[2rem] shadow-2xl"
      >
        <div className="text-center mb-10">
          <div className="w-16 h-16 gradient-primary rounded-2xl flex items-center justify-center text-white font-bold text-3xl mx-auto mb-6 shadow-lg">L</div>
          <h1 className="text-3xl font-bold mb-2">Bon retour !</h1>
          <p className="text-slate-500">Connectez-vous à votre espace LinQora</p>
        </div>

        <form onSubmit={(e) => handleLogin(e)} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="email">Email professionnel</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-3 text-slate-400" size={20} />
              <Input 
                id="email" 
                type="email" 
                placeholder="nom@entreprise.com" 
                className="pl-10 h-12 rounded-xl border-slate-200 focus:ring-primary"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <Label htmlFor="password">Mot de passe</Label>
              <a href="#" className="text-sm text-primary font-medium hover:underline">Oublié ?</a>
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-3 text-slate-400" size={20} />
              <Input 
                id="password" 
                type="password" 
                placeholder="••••••••" 
                className="pl-10 h-12 rounded-xl border-slate-200 focus:ring-primary"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
          </div>

          <Button type="submit" className="w-full btn-primary h-14 rounded-xl text-lg font-bold group">
            Se connecter
            <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
          </Button>
        </form>

        <div className="mt-10">
          <div className="relative mb-6">
            <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-slate-200"></span></div>
            <div className="relative flex justify-center text-xs uppercase"><span className="bg-white px-2 text-slate-400 font-bold">Accès Rapide Démo</span></div>
          </div>

          <div className="grid grid-cols-5 gap-2">
            {[
              { role: ['SUPER_ADMIN'], icon: ShieldAlert, label: 'Super' },
              { role: ['COMPANY_ADMIN'], icon: Building2, label: 'Admin' },
              { role: ['EVENT_MANAGER'], icon: ShieldCheck, label: 'Mngr' },
              { role: ['SCAN_OPERATOR'], icon: QrCode, label: 'Scan' },
              { role: ['PARTICIPANT'], icon: Users, label: 'Part' },
            ].map((item) => (
              <Button 
                key={item.role[0]}
                type="button"
                variant="outline" 
                className="flex flex-col h-16 rounded-xl gap-1 border-slate-100 hover:border-primary hover:text-primary p-1"
                onClick={() => handleLogin(null, item.role)}
              >
                <item.icon size={16} />
                <span className="text-[8px] font-bold">{item.label}</span>
              </Button>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Login;