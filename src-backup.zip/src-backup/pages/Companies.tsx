import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Building2, Plus, Search, MoreVertical, Users, Calendar, Globe, Trash2, Edit2, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from 'sonner';

const initialCompanies = [
  { id: '1', name: 'LinQora Tech', industry: 'SaaS / Tech', events: 12, users: 45, status: 'Actif', plan: 'Enterprise' },
  { id: '2', name: 'Global Events Co', industry: 'Événementiel', events: 84, users: 120, status: 'Actif', plan: 'Enterprise' },
  { id: '3', name: 'Startup Hub', industry: 'Incubateur', events: 5, users: 12, status: 'En attente', plan: 'Pro' },
];

const Companies = () => {
  const [companies, setCompanies] = useState(initialCompanies);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCompanies = companies.filter(company => 
    company.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    company.industry.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddCompany = () => {
    const name = prompt("Nom de la nouvelle entreprise :");
    if (name) {
      const newCompany = {
        id: Date.now().toString(),
        name,
        industry: 'Nouveau secteur',
        events: 0,
        users: 1,
        status: 'En attente',
        plan: 'Starter'
      };
      setCompanies([newCompany, ...companies]);
      toast.success(`L'entreprise "${name}" a été ajoutée.`);
    }
  };

  const handleManage = (name: string) => {
    toast.info(`Ouverture du panneau de gestion pour ${name}`);
  };

  const handleDelete = (id: string, name: string) => {
    setCompanies(companies.filter(c => c.id !== id));
    toast.error(`L'entreprise "${name}" a été supprimée.`);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Gestion des Entreprises</h1>
          <p className="text-slate-500">Supervision globale des organisations sur la plateforme.</p>
        </div>
        <Button onClick={handleAddCompany} className="btn-primary rounded-xl h-12 px-6">
          <Plus className="mr-2" size={20} /> Ajouter une entreprise
        </Button>
      </div>

      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <Input 
            placeholder="Rechercher une entreprise..." 
            className="pl-10 h-12 rounded-xl border-slate-200"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredCompanies.map((company, i) => (
          <motion.div
            key={company.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="border-none shadow-lg rounded-2xl overflow-hidden glass hover:shadow-xl transition-all">
              <CardContent className="p-6 flex flex-col md:flex-row items-center gap-6">
                <div className="w-16 h-16 gradient-primary rounded-2xl flex items-center justify-center text-white shrink-0">
                  <Building2 size={32} />
                </div>
                <div className="flex-1 text-center md:text-left">
                  <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 mb-1">
                    <h3 className="text-xl font-bold">{company.name}</h3>
                    <Badge className={cn(
                      "border-none",
                      company.status === 'Actif' ? "bg-emerald-500/10 text-emerald-600" : "bg-amber-500/10 text-amber-600"
                    )}>{company.status}</Badge>
                    <Badge variant="outline" className="border-primary text-primary">{company.plan}</Badge>
                  </div>
                  <div className="flex flex-wrap items-center justify-center md:justify-start gap-6 text-sm text-slate-500">
                    <span className="flex items-center gap-1"><Globe size={14} /> {company.industry}</span>
                    <span className="flex items-center gap-1"><Calendar size={14} /> {company.events} Événements</span>
                    <span className="flex items-center gap-1"><Users size={14} /> {company.users} Utilisateurs</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" className="rounded-xl" onClick={() => handleManage(company.name)}>Gérer</Button>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="rounded-full">
                        <MoreVertical size={20} />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="rounded-xl border-none shadow-xl">
                      <DropdownMenuItem onClick={() => handleManage(company.name)}>
                        <ExternalLink size={16} className="mr-2" /> Voir le profil
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => toast.info(`Édition de ${company.name}`)}>
                        <Edit2 size={16} className="mr-2" /> Modifier
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-red-600" onClick={() => handleDelete(company.id, company.name)}>
                        <Trash2 size={16} className="mr-2" /> Supprimer
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
        {filteredCompanies.length === 0 && (
          <div className="text-center py-20 text-slate-400">
            Aucune entreprise ne correspond à votre recherche.
          </div>
        )}
      </div>
    </div>
  );
};

import { cn } from '@/lib/utils';

export default Companies;