import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { QrCode, Calendar, MapPin, Download, ExternalLink, Ticket } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useSelector } from 'react-redux';
import { RootState } from '@/store';
import { toast } from 'sonner';
import BadgeDialog from '@/components/events/BadgeDialog';

const MyTickets = () => {
  const { events } = useSelector((state: RootState) => state.events);
  const { user } = useSelector((state: RootState) => state.auth);
  const [selectedEvent, setSelectedEvent] = useState<any>(null);
  const [isBadgeOpen, setIsBadgeOpen] = useState(false);

  // Simulation : le participant est inscrit au premier événement
  const myEvents = events.length > 0 ? [events[0]] : [];

  const handleViewBadge = (event: any) => {
    setSelectedEvent(event);
    setIsBadgeOpen(true);
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Mes Billets</h1>
        <p className="text-slate-500">Retrouvez vos accès pour vos événements à venir.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {myEvents.map((event, i) => (
          <motion.div
            key={event.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="border-none shadow-xl rounded-[2.5rem] overflow-hidden glass flex flex-col md:flex-row">
              <div className="md:w-1/3 relative h-48 md:h-auto">
                <img src={event.image} alt={event.title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/20" />
                <div className="absolute top-4 left-4">
                  <Badge className="bg-white text-primary border-none font-bold">PREMIUM</Badge>
                </div>
              </div>
              
              <CardContent className="p-8 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-2xl font-bold mb-4">{event.title}</h3>
                  <div className="space-y-2 text-slate-500 font-medium mb-6">
                    <div className="flex items-center gap-2"><Calendar size={16} className="text-primary" /> {new Date(event.date).toLocaleDateString()}</div>
                    <div className="flex items-center gap-2"><MapPin size={16} className="text-primary" /> {event.location}</div>
                  </div>
                </div>

                <div className="flex flex-wrap gap-3">
                  <Button onClick={() => handleViewBadge(event)} className="btn-primary rounded-xl flex-1">
                    <QrCode size={18} className="mr-2" /> Voir mon Badge
                  </Button>
                  <Button onClick={() => toast.success("Téléchargement lancé...")} variant="outline" className="rounded-xl">
                    <Download size={18} />
                  </Button>
                  <Button onClick={() => { navigator.clipboard.writeText(window.location.href); toast.success("Lien copié !"); }} variant="outline" className="rounded-xl">
                    <ExternalLink size={18} />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {selectedEvent && (
        <BadgeDialog 
          isOpen={isBadgeOpen} 
          onClose={() => setIsBadgeOpen(false)} 
          eventTitle={selectedEvent.title}
          participantName={user?.name || "Participant"}
        />
      )}
    </div>
  );
};

export default MyTickets;