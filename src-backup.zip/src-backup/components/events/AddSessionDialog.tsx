import React from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Calendar, Clock, MapPin, User } from 'lucide-react';
import { toast } from 'sonner';

interface AddSessionDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

const AddSessionDialog = ({ isOpen, onClose }: AddSessionDialogProps) => {
  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Session ajoutée au programme !');
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] rounded-[2rem] border-none shadow-2xl p-8">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">Ajouter une Session</DialogTitle>
          <p className="text-slate-500">Planifiez une nouvelle intervention ou un atelier.</p>
        </DialogHeader>

        <form onSubmit={handleAdd} className="space-y-6 py-4">
          <div className="space-y-2">
            <Label>Titre de la session</Label>
            <Input placeholder="Ex: Futur de la Blockchain" className="h-12 rounded-xl" required />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="flex items-center gap-2"><Clock size={14} /> Heure de début</Label>
              <Input type="time" className="h-12 rounded-xl" required />
            </div>
            <div className="space-y-2">
              <Label className="flex items-center gap-2"><Clock size={14} /> Durée (min)</Label>
              <Input type="number" placeholder="45" className="h-12 rounded-xl" required />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2"><User size={14} /> Intervenant</Label>
            <Input placeholder="Nom du speaker" className="h-12 rounded-xl" required />
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2"><MapPin size={14} /> Salle / Lieu</Label>
            <Input placeholder="Ex: Auditorium A" className="h-12 rounded-xl" required />
          </div>

          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea placeholder="Résumé de la session..." className="min-h-[100px] rounded-xl" />
          </div>

          <DialogFooter className="gap-3 pt-4">
            <Button type="button" variant="ghost" onClick={onClose} className="rounded-xl h-12 font-bold">Annuler</Button>
            <Button type="submit" className="btn-primary flex-1 rounded-xl h-12 font-bold">Ajouter au programme</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddSessionDialog;