import { create } from 'zustand';

export type Role = 'EVENT_MANAGER' | 'SCAN_OPERATOR' | 'PARTICIPANT';

interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  companyId?: string;
  avatar?: string;
}

interface AppState {
  user: User | null;
  setUser: (user: User | null) => void;
  logout: () => void;
}

export const useStore = create<AppState>((set) => ({
  user: null,
  setUser: (user) => set({ user }),
  logout: () => set({ user: null }),
}));