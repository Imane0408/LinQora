import * as React from "react"
import { cn } from "@/lib/utils"
import { TablePrimitive } from "@radix-ui/react-table"

const Table = React.forwardRef(
  ({ className, ...props }, ref) => {
    return (
      <TablePrimitive.Root
        ref={ref}
        className={cn(
          "divide-y divide-slate-100",
          className
        )}
        {...props}
      />
    )
  }
)

const TableBody = React.forwardRef(
  ({ className, ...props }, ref) => {
    return (
      <TablePrimitive.Body
        ref={ref}
        className={cn(
          "bg-white divide-y divide-slate-100",
          className
        )}
        {...props}
      />
    )
  }
)

const TableCell = React.forwardRef(
  ({ className, ...props }, ref) => {
    return (
      <TablePrimitive.Cell
        ref={ref}
        className={cn(
          "px-4 py-3 font-medium text-sm text-slate-600",
          className
        )}
        {...props}
      />
    )
  }
)

const TableHeader = React.forwardRef(
  ({ className, ...props }, ref) => {
    return (
      <TablePrimitive.Header
        ref={ref}
        className={cn(
          "px-4 py-3 bg-slate-50 font-medium text-sm text-slate-600",
          className
        )}
        {...props}
      />
    )
  }
)

const TableRow = React.forwardRef(
  ({ className, ...props }, ref) => {
    return (
      <TablePrimitive.Row
        ref={ref}
        className={cn(
          "hover:bg-slate-50",
          className
        )}
        {...props}
      />
    )
  }
)

export {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
}