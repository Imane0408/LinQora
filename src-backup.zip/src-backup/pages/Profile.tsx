import React, { useState, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '@/store';
import { updateUser } from '@/store/slices/authSlice';
import { motion } from 'framer-motion';
import { User, Mail, Briefcase, MapPin, Camera, Save, Plus, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { toast } from 'sonner';

const Profile = () => {
  const { user } = useSelector((state: RootState) => state.auth);
  const dispatch = useDispatch();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | undefined>(user?.avatar);
  const [isInterestOpen, setIsInterestOpen] = useState(false);
  const [newInterest, setNewInterest] = useState('');
  const [interests, setInterests] = useState(['Intelligence Artificielle', 'Web3', 'Marketing Digital', 'SaaS', 'Financement', 'Recrutement']);

  const handleSave = () => {
    toast.success('Profil mis à jour avec succès !');
  };

  const handleAddInterest = () => {
    if (newInterest.trim()) {
      setInterests([...interests, newInterest.trim()]);
      setNewInterest('');
      setIsInterestOpen(false);
      toast.success(`Intérêt ajouté !`);
    }
  };

  const removeInterest = (tag: string) => {
    setInterests(interests.filter(i => i !== tag));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setAvatarPreview(base64);
        dispatch(updateUser({ avatar: base64 }));
        toast.success("Photo de profil mise à jour !");
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Mon Profil</h1>
        <Button onClick={handleSave} className="btn-primary rounded-xl h-12 px-6">
          <Save className="mr-2" size={20} /> Enregistrer
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Colonne Gauche : Avatar & Stats */}
        <div className="space-y-8">
          <Card className="border-none shadow-xl rounded-[2.5rem] overflow-hidden glass">
            <CardContent className="p-8 text-center">
              <div className="relative inline-block mb-6">
                <Avatar className="h-32 w-32 border-4 border-white shadow-2xl">
                  <AvatarImage src={avatarPreview} />
                  <AvatarFallback className="gradient-primary text-white text-4xl font-bold">
                    {user?.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
                <Button size="icon" className="absolute bottom-0 right-0 rounded-full btn-primary h-10 w-10 border-4 border-white" onClick={() => fileInputRef.current?.click()}><Camera size={18} /></Button>
              </div>
              <h2 className="text-2xl font-bold">{user?.name}</h2>
              <p className="text-slate-500 font-medium mb-4">{user?.role.replace('_', ' ')}</p>
              <Badge className="bg-primary/10 text-primary border-none rounded-full px-4 py-1">ID: #4829</Badge>
            </CardContent>
          </Card>

          <Card className="border-none shadow-xl rounded-[2.5rem] p-8 glass">
            <CardTitle className="text-lg font-bold mb-6">Statistiques</CardTitle>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Événements</span>
                <span className="font-bold">12</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Contacts</span>
                <span className="font-bold">148</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Rendez-vous</span>
                <span className="font-bold">34</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Colonne Droite : Formulaire & Intérêts */}
        <div className="lg:col-span-2 space-y-8">
          <Card className="border-none shadow-xl rounded-[2.5rem] p-10 glass">
            <CardHeader className="px-0 pt-0"><CardTitle className="text-xl font-bold">Informations Personnelles</CardTitle></CardHeader>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Nom complet</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 text-slate-400" size={20} />
                  <Input defaultValue={user?.name} className="pl-10 h-12 rounded-xl" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 text-slate-400" size={20} />
                  <Input defaultValue={user?.email} className="pl-10 h-12 rounded-xl" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Poste / Fonction</Label>
                <div className="relative">
                  <Briefcase className="absolute left-3 top-3 text-slate-400" size={20} />
                  <Input placeholder="Ex: Directeur Marketing" className="pl-10 h-12 rounded-xl" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Ville / Pays</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 text-slate-400" size={20} />
                  <Input placeholder="Paris, France" className="pl-10 h-12 rounded-xl" />
                </div>
              </div>
            </div>
          </Card>

          <Card className="border-none shadow-xl rounded-[2.5rem] p-10 glass">
            <CardHeader className="px-0 pt-0"><CardTitle className="text-xl font-bold">Intérêts Networking</CardTitle></CardHeader>
            <div className="space-y-6">
              <div className="flex flex-wrap gap-2">
                {interests.map((tag) => (
                  <Badge key={tag} className="bg-slate-100 text-slate-600 rounded-full px-4 py-2 border-none flex items-center gap-2">
                    {tag}
                    <X size={14} className="cursor-pointer hover:text-red-500" onClick={() => removeInterest(tag)} />
                  </Badge>
                ))}
                <Button variant="outline" className="rounded-full border-dashed border-2 h-10" onClick={() => setIsInterestOpen(true)}>
                  <Plus size={16} className="mr-2" /> Ajouter
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>

      <Dialog open={isInterestOpen} onOpenChange={setIsInterestOpen}>
        <DialogContent className="sm:max-w-[400px] rounded-[2rem] p-8">
          <DialogHeader><DialogTitle>Ajouter un intérêt</DialogTitle></DialogHeader>
          <div className="py-4">
            <Input 
              placeholder="Ex: Blockchain, Design..." 
              value={newInterest} 
              onChange={(e) => setNewInterest(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleAddInterest()}
              className="h-12 rounded-xl"
            />
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setIsInterestOpen(false)}>Annuler</Button>
            <Button onClick={handleAddInterest} className="btn-primary rounded-xl">Ajouter</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Profile;