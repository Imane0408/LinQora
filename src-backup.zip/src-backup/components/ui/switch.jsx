import * as React from "react"
import * as SwitchPrimitive from "@radix-ui/react-switch"
import { cn } from "@/lib/utils"

const Switch = React.forwardRef(
  ({ className, ...props }, ref) => {
    return (
      <SwitchPrimitive.Root        ref={ref}
        className={cn(
          "relative inline-flex h-6 w-11 items-center cursor-pointer rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50 data-[state=on]:bg-primary data-[state=off]:bg-slate-200 data-[state=on]:ring-primary data-[state=off]:ring-slate-50",
          className
        )}
        {...props}
      />
    )
  }
)

const SwitchThumb = React.forwardRef(
  ({ className, ...props }, ref) => {
    return (
      <SwitchPrimitive.Thumb
        ref={ref}
        className={cn(
          "relative flex h-4 w-4 transform transition-transform duration-150 ease-in-out rounded-full bg-white shadow-sm",
          className
        )}
        {...props}
      />
    )
  }
)

Switch.displayName = SwitchPrimitives.Root.displayNameexport { Switch, SwitchThumb }