import { createSlice } from '@reduxjs/toolkit';

const authSlice = createSlice({
  name: 'auth',
  initialState: {
    user: null,
    token: null,
    isAuthenticated: false,
  },
  reducers: {
    setCredentials: (state, action) => {
      state.user = action.payload.user;
      state.token = action.payload.token;
      state.isAuthenticated = true;
    },
    logout: (state) => {
      state.user = null;
      state.token = null;
      state.isAuthenticated = false;
    },
    updateUser: (state, action) => {
      if (state.user) {
        state.user = { ...state.user, ...action.payload };
      }
    },
  },
});

export const { setCredentials, logout, updateUser } = authSlice.actions;
export default authSlice.reducer;

// Fonctions utilitaires pour les rôles
export const hasRole = (user, role) => {
  if (!user || !user.role) return false;
  return user.role.includes(role);
};

export const hasAnyRole = (user, roles) => {
  if (!user || !user.role) return false;
  return roles.some(role => user.role.includes(role));
};

export const hasAllRoles = (user, roles) => {
  if (!user || !user.role) return false;
  return roles.every(role => user.role.includes(role));
};