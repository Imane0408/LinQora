import React from 'react';
import { motion } from 'framer-motion';
import { Users, Calendar, TrendingUp, ArrowUpRight, MoreVertical, Clock } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { toast } from 'sonner';
import { exportToCSV } from '@/utils/export';

const data = [
  { name: 'Lun', inscrits: 40 },
  { name: 'Mar', inscrits: 30 },
  { name: 'Mer', inscrits: 20 },
  { name: 'Jeu', inscrits: 27 },
  { name: 'Ven', inscrits: 18 },
  { name: 'Sam', inscrits: 23 },
  { name: 'Dim', inscrits: 34 },
];

const Dashboard = () => {
  const { events } = useSelector((state) => state.events);
  
  const totalInscrits = events.reduce((acc, curr) => acc + curr.participants, 0);
  const totalCapacity = events.reduce((acc, curr) => acc + curr.capacity, 0);
  const participationRate = totalCapacity > 0 ? Math.round((totalInscrits / totalCapacity) * 100) : 0;

  const handleExport = () => {
    exportToCSV(events, 'dashboard_stats');
    toast.success("Données exportées !");
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Tableau de bord</h1>
          <p className="text-slate-500">Bienvenue sur votre espace LinQora.</p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" className="rounded-xl" onClick={handleExport}>Exporter</Button>
          <Link to="/events/create"><Button className="btn-primary rounded-xl">Créer un événement</Button></Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { title: "Total Inscrits", value: totalInscrits, icon: Users, color: "bg-blue-500" },
          { title: "Événements", value: events.length, icon: Calendar, color: "bg-emerald-500" },
          { title: "Remplissage", value: `${participationRate}%`, icon: TrendingUp, color: "bg-violet-500" },
          { title: "RDV", value: "342", icon: Clock, color: "bg-pink-500" },
        ].map((kpi, i) => (
          <Card key={i} className="border-none shadow-lg rounded-[2rem] overflow-hidden">
            <CardContent className="p-6">
              <div className={cn("w-12 h-12 rounded-2xl text-white flex items-center justify-center mb-4", kpi.color)}>
                <kpi.icon size={24} />
              </div>
              <p className="text-slate-500 font-medium">{kpi.title}</p>
              <h3 className="text-3xl font-extrabold">{kpi.value}</h3>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2 border-none shadow-lg rounded-[2.5rem] p-6">
          <CardHeader className="px-0 pt-0"><CardTitle className="text-xl font-bold">Inscriptions</CardTitle></CardHeader>
          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip />
                <Area type="monotone" dataKey="inscrits" stroke="#4361EE" fill="#4361EE33" strokeWidth={3} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="border-none shadow-lg rounded-[2.5rem] p-6">
          <CardHeader className="px-0 pt-0 flex flex-row items-center justify-between">
            <CardTitle className="text-xl font-bold">Activités</CardTitle>
          </CardHeader>
          <div className="space-y-6 mt-4">
            {[
              { user: "Jean Dupont", action: "s'est inscrit", target: "Tech Summit", time: "2 min" },
              { user: "Marie Curie", action: "a scanné", target: "Atelier IA", time: "15 min" },
            ].map((activity, i) => (
              <div key={i} className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center font-bold">{activity.user.charAt(0)}</div>
                <div>
                  <p className="text-sm"><span className="font-bold">{activity.user}</span> {activity.action} <span className="text-primary">{activity.target}</span></p>
                  <p className="text-xs text-slate-400">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
          <Link to="/history"><Button variant="ghost" className="w-full mt-6 text-primary font-bold">Voir tout l'historique</Button></Link>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;