import React, { useState } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Send, Smile, Paperclip } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';

interface ChatDialogProps {
  isOpen: boolean;
  onClose: () => void;
  participant: {
    name: string;
    avatar: string;
    role: string;
  } | null;
}

const ChatDialog = ({ isOpen, onClose, participant }: ChatDialogProps) => {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([
    { id: 1, text: "Bonjour ! J'ai vu votre profil, votre expertise en IA m'intéresse beaucoup.", sender: 'them', time: '10:30' },
    { id: 2, text: "Bonjour ! Merci, je serais ravi d'en discuter. Vous travaillez sur quel projet ?", sender: 'me', time: '10:32' },
  ]);

  const handleSend = () => {
    if (!message.trim()) return;
    
    const newMessage = {
      id: Date.now(),
      text: message,
      sender: 'me',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    
    setMessages([...messages, newMessage]);
    setMessage('');
    
    // Simulation d'une réponse automatique après 1 seconde
    setTimeout(() => {
      toast.success("Message envoyé !");
    }, 500);
  };

  const handleAction = (type: string) => {
    toast.info(`Fonctionnalité ${type} bientôt disponible avec le backend Laravel.`);
  };

  if (!participant) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] p-0 overflow-hidden rounded-[2rem] border-none shadow-2xl">
        <DialogHeader className="p-6 gradient-primary text-white">
          <div className="flex items-center gap-4">
            <Avatar className="h-12 w-12 border-2 border-white/20">
              <AvatarImage src={participant.avatar} />
              <AvatarFallback>{participant.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="text-left">
              <DialogTitle className="text-xl font-bold">{participant.name}</DialogTitle>
              <p className="text-xs text-white/80">{participant.role}</p>
            </div>
          </div>
        </DialogHeader>

        <ScrollArea className="h-[400px] p-6 bg-slate-50">
          <div className="space-y-4">
            {messages.map((msg) => (
              <div key={msg.id} className={cn(
                "flex flex-col max-w-[80%]",
                msg.sender === 'me' ? "ml-auto items-end" : "items-start"
              )}>
                <div className={cn(
                  "px-4 py-3 rounded-2xl text-sm font-medium shadow-sm",
                  msg.sender === 'me' ? "bg-primary text-white rounded-tr-none" : "bg-white text-slate-700 rounded-tl-none"
                )}>
                  {msg.text}
                </div>
                <span className="text-[10px] text-slate-400 mt-1">{msg.time}</span>
              </div>
            ))}
          </div>
        </ScrollArea>

        <div className="p-4 bg-white border-t flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-slate-400 rounded-full"
            onClick={() => handleAction("Pièces jointes")}
          >
            <Paperclip size={20} />
          </Button>
          <Input 
            placeholder="Votre message..." 
            className="flex-1 h-12 rounded-xl border-slate-100 bg-slate-50 focus:ring-primary"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
          />
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-slate-400 rounded-full"
            onClick={() => handleAction("Emojis")}
          >
            <Smile size={20} />
          </Button>
          <Button onClick={handleSend} className="btn-primary h-12 w-12 rounded-xl p-0">
            <Send size={20} />
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

import { cn } from '@/lib/utils';

export default ChatDialog;