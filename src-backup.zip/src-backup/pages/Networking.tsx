"use client";

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Users, 
  MessageSquare, 
  Calendar, 
  Search, 
  Filter, 
  Handshake, 
  Briefcase, 
  ChevronRight, 
  UserCheck, 
  Clock, 
  MapPin,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import ChatDialog from '@/components/networking/ChatDialog';
import MeetingRequestDialog from '@/components/networking/MeetingRequestDialog';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

const initialMatches = [
  {
    id: '1',
    name: 'Sarah Connor',
    role: 'CTO @ Cyberdyne',
    interests: ['IA', 'Robotique', 'Sécurité'],
    matchScore: 98,
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200',
    status: 'Disponible'
  },
  {
    id: '2',
    name: 'Elon Musk',
    role: 'CEO @ X Space',
    interests: ['Espace', 'Énergie', 'IA'],
    matchScore: 85,
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
    status: 'En rendez-vous'
  },
  {
    id: '3',
    name: 'Ada Lovelace',
    role: 'Lead Dev @ Algorithm',
    interests: ['Maths', 'Python', 'Web3'],
    matchScore: 92,
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=200',
    status: 'Disponible'
  }
];

const initialMeetings = [
  { id: 'm1', name: 'Sarah Connor', time: '14:00', date: '15 Mai', location: 'Zone A', status: 'Confirmé', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200', role: 'CTO @ Cyberdyne' },
  { id: 'm2', name: 'Elon Musk', time: '16:30', date: '15 Mai', location: 'Lounge VIP', status: 'En attente', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200', role: 'CEO @ X Space' },
];

const connections = [
  { id: '4', name: 'Bill Gates', role: 'Founder @ Microsoft', avatar: '', lastMsg: 'On se voit à 15h ?', time: '10:45' },
  { id: '5', name: 'Steve Jobs', role: 'Founder @ Apple', avatar: '', lastMsg: 'Super présentation !', time: 'Hier' },
];

const allSectors = ['IA', 'Web3', 'Robotique', 'Espace', 'Énergie', 'Sécurité', 'Maths', 'Python'];

const Networking = () => {
  const [selectedParticipant, setSelectedParticipant] = useState<any>(null);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isMeetingOpen, setIsMeetingOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSectors, setSelectedSectors] = useState<string[]>([]);
  const [meetings, setMeetings] = useState(initialMeetings);

  const filteredMatches = initialMatches.filter(match => {
    const matchesSearch = match.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         match.role.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesSector = selectedSectors.length === 0 || 
                         match.interests.some(interest => selectedSectors.includes(interest));
    
    return matchesSearch && matchesSector;
  });

  const toggleSector = (sector: string) => {
    setSelectedSectors(prev => 
      prev.includes(sector) ? prev.filter(s => s !== sector) : [...prev, sector]
    );
  };

  const openChat = (participant: any) => {
    setSelectedParticipant(participant);
    setIsChatOpen(true);
  };

  const openMeeting = (participant: any) => {
    setSelectedParticipant(participant);
    setIsMeetingOpen(true);
  };

  const handleCancelMeeting = (id: string, name: string) => {
    setMeetings(prev => prev.filter(m => m.id !== id));
    toast.error(`Le rendez-vous avec ${name} a été annulé.`);
  };

  const handleMeetingDetails = (meeting: any) => {
    toast.info(`Détails : RDV avec ${meeting.name} le ${meeting.date} à ${meeting.time} (${meeting.location})`);
  };

  const handleSeeAllContacts = () => {
    toast.promise(
      new Promise((resolve) => setTimeout(resolve, 1000)),
      {
        loading: 'Chargement de vos contacts...',
        success: 'Liste des contacts mise à jour !',
        error: 'Erreur lors du chargement.',
      }
    );
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Networking Intelligent</h1>
          <p className="text-slate-500">Rencontrez les bonnes personnes grâce à notre algorithme.</p>
        </div>
      </div>

      <Tabs defaultValue="discover" className="space-y-8">
        <TabsList className="bg-slate-100 p-1 rounded-2xl h-14 w-full md:w-auto">
          <TabsTrigger value="discover" className="rounded-xl px-8 font-bold data-[state=active]:gradient-primary data-[state=active]:text-white">Découvrir</TabsTrigger>
          <TabsTrigger value="meetings" className="rounded-xl px-8 font-bold data-[state=active]:gradient-primary data-[state=active]:text-white">Mes RDV</TabsTrigger>
        </TabsList>

        <TabsContent value="discover">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <div className="flex flex-col md:flex-row gap-4 mb-8">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <Input 
                    placeholder="Rechercher par compétence, secteur, nom..." 
                    className="pl-10 h-12 rounded-xl border-slate-200"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className={cn(
                      "h-12 rounded-xl border-slate-200",
                      selectedSectors.length > 0 && "border-primary text-primary bg-primary/5"
                    )}>
                      <Filter className="mr-2" size={18} /> 
                      Secteurs {selectedSectors.length > 0 && `(${selectedSectors.length})`}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-64 p-4 rounded-2xl border-none shadow-2xl" align="end">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-bold text-slate-400 uppercase">Filtrer par secteur</p>
                        {selectedSectors.length > 0 && (
                          <button onClick={() => setSelectedSectors([])} className="text-[10px] text-primary font-bold">Effacer</button>
                        )}
                      </div>
                      <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto pr-2">
                        {allSectors.map(sector => (
                          <div key={sector} className="flex items-center space-x-2">
                            <Checkbox 
                              id={sector} 
                              checked={selectedSectors.includes(sector)}
                              onCheckedChange={() => toggleSector(sector)}
                            />
                            <Label htmlFor={sector} className="text-sm cursor-pointer">{sector}</Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  </PopoverContent>
                </Popover>
              </div>

              <h2 className="text-xl font-bold flex items-center gap-2">
                <Handshake className="text-primary" /> Recommandations pour vous
              </h2>
              <div className="space-y-4">
                <AnimatePresence mode="popLayout">
                  {filteredMatches.map((match, i) => (
                    <motion.div
                      key={match.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ delay: i * 0.05 }}
                    >
                      <Card className="border-none shadow-lg rounded-[2rem] overflow-hidden card-hover group">
                        <CardContent className="p-6">
                          <div className="flex items-start gap-4">
                            <div className="relative">
                              <Avatar className="h-20 w-20 border-4 border-white shadow-xl">
                                <AvatarImage src={match.avatar} />
                                <AvatarFallback className="bg-slate-100 text-slate-400 font-bold">{match.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <div className={cn(
                                "absolute bottom-1 right-1 w-4 h-4 rounded-full border-2 border-white",
                                match.status === 'Disponible' ? "bg-emerald-500" : "bg-amber-500"
                              )} />
                            </div>
                            <div className="flex-1">
                              <div className="flex justify-between items-start">
                                <div>
                                  <h3 className="text-lg font-bold">{match.name}</h3>
                                  <p className="text-sm text-slate-500 flex items-center gap-1">
                                    <Briefcase size={14} /> {match.role}
                                  </p>
                                </div>
                                <Badge className="gradient-primary text-white rounded-full px-3">
                                  {match.matchScore}% Match
                                </Badge>
                              </div>
                              <div className="flex flex-wrap gap-2 mt-4">
                                {match.interests.map((tag) => (
                                  <Badge key={tag} variant="secondary" className="rounded-full bg-slate-100 text-slate-600 border-none">
                                    {tag}
                                  </Badge>
                                ))}
                              </div>
                              <div className="flex gap-2 mt-6">
                                <Button onClick={() => openChat(match)} className="flex-1 btn-primary rounded-xl h-10">
                                  <MessageSquare size={16} className="mr-2" /> Chat
                                </Button>
                                <Button onClick={() => openMeeting(match)} variant="outline" className="flex-1 rounded-xl h-10 border-primary text-primary hover:bg-primary/5">
                                  <Calendar size={16} className="mr-2" /> RDV
                                </Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </AnimatePresence>
                {filteredMatches.length === 0 && (
                  <div className="text-center py-20 bg-white rounded-[2rem] border-2 border-dashed border-slate-100">
                    <p className="text-slate-400">Aucun profil ne correspond à vos filtres.</p>
                    <Button variant="ghost" className="mt-2 text-primary font-bold" onClick={() => {setSelectedSectors([]); setSearchQuery('');}}>Réinitialiser</Button>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-8">
              <Card className="border-none shadow-xl rounded-[2.5rem] p-8 glass">
                <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                  <UserCheck className="text-primary" size={20} /> Mes Connexions
                </h3>
                <div className="space-y-6">
                  {connections.map((conn) => (
                    <div key={conn.id} className="flex gap-4 items-center group cursor-pointer" onClick={() => openChat(conn)}>
                      <Avatar className="h-12 w-12 border-2 border-primary/10">
                        <AvatarFallback className="bg-primary/5 text-primary font-bold">{conn.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-center">
                          <h4 className="font-bold text-sm truncate">{conn.name}</h4>
                          <span className="text-[10px] text-slate-400">{conn.time}</span>
                        </div>
                        <p className="text-xs text-slate-500 truncate">{conn.lastMsg}</p>
                      </div>
                      <ChevronRight size={16} className="text-slate-300 group-hover:text-primary transition-colors" />
                    </div>
                  ))}
                </div>
                <Button 
                  onClick={handleSeeAllContacts} 
                  variant="ghost" 
                  className="w-full mt-6 text-primary font-bold"
                >
                  Voir tous mes contacts
                </Button>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="meetings">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence mode="popLayout">
              {meetings.map((meeting) => (
                <motion.div
                  key={meeting.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                >
                  <Card className="border-none shadow-lg rounded-[2rem] p-6 glass card-hover">
                    <div className="flex justify-between items-start mb-6">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-12 w-12 border-2 border-primary/10">
                          <AvatarImage src={meeting.avatar} />
                          <AvatarFallback className="bg-primary/5 text-primary font-bold">{meeting.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="font-bold">{meeting.name}</h4>
                          <Badge className={cn(
                            "text-[10px] font-bold uppercase",
                            meeting.status === 'Confirmé' ? "bg-emerald-500" : "bg-amber-500"
                          )}>
                            {meeting.status}
                          </Badge>
                        </div>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="rounded-full hover:bg-primary/10 hover:text-primary"
                        onClick={() => openChat(meeting)}
                      >
                        <MessageSquare size={18} />
                      </Button>
                    </div>
                    <div className="space-y-3 text-sm text-slate-500 font-medium">
                      <div className="flex items-center gap-2"><Calendar size={16} className="text-primary" /> {meeting.date} à {meeting.time}</div>
                      <div className="flex items-center gap-2"><MapPin size={16} className="text-primary" /> {meeting.location}</div>
                    </div>
                    <div className="flex gap-2 mt-6">
                      <Button variant="outline" className="flex-1 rounded-xl" onClick={() => handleCancelMeeting(meeting.id, meeting.name)}>Annuler</Button>
                      <Button className="flex-1 btn-primary rounded-xl" onClick={() => handleMeetingDetails(meeting)}>Détails</Button>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
            {meetings.length === 0 && (
              <div className="col-span-full text-center py-20">
                <p className="text-slate-400">Vous n'avez aucun rendez-vous programmé.</p>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>

      <ChatDialog 
        isOpen={isChatOpen} 
        onClose={() => setIsChatOpen(false)} 
        participant={selectedParticipant} 
      />

      <MeetingRequestDialog
        isOpen={isMeetingOpen}
        onClose={() => setIsMeetingOpen(false)}
        participant={selectedParticipant}
      />
    </div>
  );
};

export default Networking;