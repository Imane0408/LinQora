import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { logout } from '@/store/slices/authSlice';
import { 
  LayoutDashboard, 
  Calendar, 
  Users, 
  QrCode, 
  Menu, 
  LogOut, 
  Building2, 
  History, 
  Ticket, 
  Briefcase, 
  UserCircle, 
  Settings, 
  Bell, 
  Shield, 
  MessageSquare, 
  UserPlus 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { toast } from 'sonner';

const DashboardLayout = ({ children }) => {
  const { user } = useSelector((state) => state.auth);
  const { events } = useSelector((state) => state.events);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handleLogout = () => {
    dispatch(logout());
    navigate('/login');
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.length > 2) {
      const found = events.find(ev => ev.title.toLowerCase().includes(searchQuery.toLowerCase()));
      if (found) {
        navigate(`/events/${found.id}`);
        setSearchQuery('');
        toast.success(`Événement trouvé : ${found.title}`);
      } else {
        toast.error("Aucun événement correspondant trouvé.");
      }
    }
  };

  const notifications = [
    { id: 1, title: "Nouveau message", desc: "Sarah Connor vous a envoyé un message.", icon: MessageSquare, color: "text-blue-500", bg: "bg-blue-50" },
    { id: 2, title: "Nouvelle inscription", desc: "Jean Dupont s'est inscrit à Tech Summit.", icon: UserPlus, color: "text-emerald-500", bg: "bg-emerald-50" },
    { id: 3, title: "Alerte Système", desc: "Mise à jour de la plateforme terminée.", icon: Shield, color: "text-amber-500", bg: "bg-amber-50" },
  ];

  const menuItems = [
    { 
      icon: LayoutDashboard, 
      label: 'Tableau de bord', 
      path: '/dashboard', 
      roles: ['SUPER_ADMIN', 'COMPANY_ADMIN', 'EVENT_MANAGER', 'PARTICIPANT', 'SPEAKER'] 
    },
    { 
      icon: Building2, 
      label: 'Entreprises', 
      path: '/companies', 
      roles: ['SUPER_ADMIN'] 
    },
    { 
      icon: Calendar, 
      label: 'Événements', 
      path: '/events', 
      roles: ['SUPER_ADMIN', 'COMPANY_ADMIN', 'EVENT_MANAGER', 'PARTICIPANT', 'SPEAKER'] 
    },
    { 
      icon: Users, 
      label: 'Participants', 
      path: '/participants', 
      roles: ['SUPER_ADMIN', 'COMPANY_ADMIN', 'EVENT_MANAGER'] 
    },
    { 
      icon: QrCode, 
      label: 'Scanner QR', 
      path: '/scan', 
      roles: ['SUPER_ADMIN', 'EVENT_MANAGER', 'SCAN_OPERATOR'] 
    },
    { 
      icon: History, 
      label: 'Historique Global', 
      path: '/history', 
      roles: ['SUPER_ADMIN'] 
    },
    { 
      icon: Ticket, 
      label: 'Mes Billets', 
      path: '/my-tickets', 
      roles: ['SUPER_ADMIN', 'COMPANY_ADMIN', 'EVENT_MANAGER', 'PARTICIPANT', 'SPEAKER'] 
    },
    { 
      icon: Briefcase, 
      label: 'Networking', 
      path: '/networking', 
      roles: ['SUPER_ADMIN', 'COMPANY_ADMIN', 'EVENT_MANAGER', 'PARTICIPANT', 'SPEAKER'] 
    },
    { 
      icon: UserCircle, 
      label: 'Mon Profil', 
      path: '/profile', 
      roles: ['SUPER_ADMIN', 'COMPANY_ADMIN', 'EVENT_MANAGER', 'SCAN_OPERATOR', 'PARTICIPANT', 'SPEAKER'] 
    },
    { 
      icon: Settings, 
      label: 'Paramètres', 
      path: '/settings', 
      roles: ['SUPER_ADMIN', 'COMPANY_ADMIN', 'EVENT_MANAGER'] 
    },
  ].filter(item => user && user.role && item.roles.some(role => user.role.includes(role)));

  const SidebarContent = () => (
    <div className="flex flex-col h-full p-6">
      <div className="flex items-center justify-between mb-10">
        <Link to="/dashboard" className={cn("flex items-center gap-3", isSidebarCollapsed && "lg:hidden")}>
          <div className="w-10 h-10 gradient-primary rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg">L</div>
          <span className="text-2xl font-bold text-gradient">LinQora</span>
        </Link>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          className="hidden lg:flex"
        >
          {isSidebarCollapsed ? <Menu size={20} /> : <LogOut size={20} />}
        </Button>
      </div>

      <nav className="flex-1 space-y-2">
        {menuItems.map((item, index) => {
          const isParticipantSection = item.path === '/my-tickets';
          const showSeparator = isParticipantSection && user && user.role && ['SUPER_ADMIN', 'COMPANY_ADMIN', 'EVENT_MANAGER'].some(r => user.role.includes(r));

          return (
            <React.Fragment key={item.path}>
              {showSeparator && (
                <div className="pt-4 pb-2 px-4">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Espace Personnel</p>
                </div>
              )}
              <Link
                to={item.path}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group",
                  location.pathname === item.path 
                    ? "gradient-primary text-white shadow-lg" 
                    : "text-slate-600 hover:bg-white hover:shadow-md"
                )}
              >
                <item.icon size={22} className={cn(
                  location.pathname === item.path ? "text-white" : "text-slate-400 group-hover:text-primary"
                )} />
                <span className={cn("font-semibold transition-opacity", isSidebarCollapsed && "lg:hidden")}>
                  {item.label}
                </span>
              </Link>
            </React.Fragment>
          );
        })}
      </nav>

      <div className="mt-auto pt-6 border-t border-slate-200">
        <div className={cn("flex items-center gap-3 mb-6", isSidebarCollapsed && "lg:hidden")}>
          <Avatar className="h-10 w-10 border-2 border-primary/20">
            <AvatarImage src={user?.avatar} />
            <AvatarFallback className="bg-primary/10 text-primary font-bold">
              {user?.name?.charAt(0)}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold truncate">{user?.name}</p>
            <p className="text-xs text-slate-500 truncate">
              {user?.role?.map ? user.role.map(r => r.replace('_', ' ')).join(', ') : user?.role?.replace('_', ' ') || ''}
            </p>
          </div>
        </div>
        <button 
          onClick={handleLogout}
          className="flex items-center gap-3 px-4 py-3 w-full rounded-xl text-slate-600 hover:bg-red-50 hover:text-red-600 transition-all duration-200 group"
        >
          <LogOut size={22} className="text-slate-400 group-hover:text-red-600" />
          <span className={cn("font-semibold", isSidebarCollapsed && "lg:hidden")}>Déconnexion</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#F8F9FA] flex">
      <aside className={cn(
        "hidden lg:block fixed inset-y-0 left-0 z-50 glass border-r transition-all duration-300",
        isSidebarCollapsed ? "w-24" : "w-72"
      )}>
        <SidebarContent />
      </aside>

      <div className={cn(
        "flex-1 flex flex-col min-w-0 overflow-hidden transition-all duration-300",
        isSidebarCollapsed ? "lg:ml-24" : "lg:ml-72"
      )}>
        <header className="h-20 glass border-b px-4 md:px-8 flex items-center justify-between sticky top-0 z-40">
          <div className="flex items-center gap-4 flex-1">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="lg:hidden">
                  <Menu size={24} />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="p-0 w-72">
                <SidebarContent />
              </SheetContent>
            </Sheet>

            <form onSubmit={handleSearch} className="relative w-full max-w-md hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="text" 
                placeholder="Rechercher un événement (ex: Tech Summit)..." 
                className="w-full pl-10 pr-4 py-2 bg-slate-100/50 border-none rounded-xl focus:ring-2 focus:ring-primary/20 transition-all"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </form>
          </div>

          <div className="flex items-center gap-2 md:gap-4">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="icon" className="relative rounded-full bg-white shadow-sm">
                  <Bell size={20} className="text-slate-600" />
                  <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80 p-0 rounded-3xl border-none shadow-2xl overflow-hidden">
                <div className="p-4 gradient-primary text-white font-bold flex justify-between items-center">
                  <span>Notifications</span>
                  <Badge className="bg-white/20 text-white border-none">3 Nouvelles</Badge>
                </div>
                <div className="divide-y divide-slate-50">
                  {notifications.map((n) => (
                    <div key={n.id} className="p-4 flex gap-3 hover:bg-slate-50 transition-colors cursor-pointer">
                      <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center shrink-0", n.bg, n.color)}>
                        <n.icon size={20} />
                      </div>
                      <div>
                        <p className="text-sm font-bold">{n.title}</p>
                        <p className="text-xs text-slate-500">{n.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <Button 
                  variant="ghost" 
                  className="w-full rounded-none h-12 text-primary font-bold border-t"
                  onClick={() => toast.info("Toutes les notifications ont été marquées comme lues.")}
                >
                  Voir tout
                </Button>
              </PopoverContent>
            </Popover>

            <div className="h-8 w-[1px] bg-slate-200 mx-1 md:mx-2"></div>
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-bold">{user?.name}</p>
                <p className="text-xs text-slate-500">ID: #4829</p>
              </div>
              <Avatar className="h-10 w-10 cursor-pointer hover:ring-2 hover:ring-primary transition-all">
                <AvatarImage src={user?.avatar} />
                <AvatarFallback className="gradient-primary text-white font-bold">
                  {user?.name?.charAt(0)}
                </AvatarFallback>
              </Avatar>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          {children}
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;