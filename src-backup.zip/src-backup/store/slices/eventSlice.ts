import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export interface Session {
  id: string;
  title: string;
  time: string;
  room: string;
  speaker?: string;
  description?: string;
}

export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  location: string;
  participants: number;
  capacity: number;
  status: 'Publié' | 'Brouillon' | 'Programmé';
  image: string;
  type: 'Présentiel' | 'Hybride' | 'Virtuel';
  visibility?: 'public' | 'private';
  sessions?: Session[];
}

interface EventState {
  events: Event[];
}

const defaultEvents: Event[] = [
  {
    id: '1',
    title: 'Tech Summit 2024',
    description: 'Le plus grand rassemblement tech de l\'année.',
    date: '2024-05-15T09:00',
    location: 'Palais des Congrès, Paris',
    participants: 450,
    capacity: 500,
    status: 'Publié',
    image: 'https://images.unsplash.com/photo-1540575861501-7cf05a4b125a?auto=format&fit=crop&q=80&w=1000',
    type: 'Présentiel',
    visibility: 'public',
    sessions: [
      { id: 's1', title: "Ouverture", time: "09:00", room: "Auditorium A", speaker: "Sarah Connor" }
    ]
  },
  {
    id: '2',
    title: 'Atelier IA & Business',
    description: 'Comment l\'IA transforme le monde des affaires.',
    date: '2024-06-12T14:00',
    location: 'Hybride (Zoom + Lyon)',
    participants: 120,
    capacity: 200,
    status: 'Brouillon',
    image: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&q=80&w=1000',
    type: 'Hybride',
    visibility: 'private',
    sessions: []
  }
];

const savedEvents = localStorage.getItem('linqora_events');
const initialState: EventState = {
  events: savedEvents ? JSON.parse(savedEvents) : defaultEvents,
};

const eventSlice = createSlice({
  name: 'events',
  initialState,
  reducers: {
    addEvent: (state, action: PayloadAction<Event>) => {
      state.events.unshift(action.payload);
      localStorage.setItem('linqora_events', JSON.stringify(state.events));
    },
    updateEvent: (state, action: PayloadAction<Event>) => {
      const index = state.events.findIndex(e => e.id === action.payload.id);
      if (index !== -1) {
        state.events[index] = action.payload;
        localStorage.setItem('linqora_events', JSON.stringify(state.events));
      }
    },
    deleteEvent: (state, action: PayloadAction<string>) => {
      state.events = state.events.filter(e => e.id !== action.payload);
      localStorage.setItem('linqora_events', JSON.stringify(state.events));
    },
    addSession: (state, action: PayloadAction<{ eventId: string; session: Session }>) => {
      const event = state.events.find(e => e.id === action.payload.eventId);
      if (event) {
        if (!event.sessions) event.sessions = [];
        event.sessions.push(action.payload.session);
        localStorage.setItem('linqora_events', JSON.stringify(state.events));
      }
    },
    updateSession: (state, action: PayloadAction<{ eventId: string; session: Session }>) => {
      const event = state.events.find(e => e.id === action.payload.eventId);
      if (event && event.sessions) {
        const sIndex = event.sessions.findIndex(s => s.id === action.payload.session.id);
        if (sIndex !== -1) {
          event.sessions[sIndex] = action.payload.session;
          localStorage.setItem('linqora_events', JSON.stringify(state.events));
        }
      }
    },
    deleteSession: (state, action: PayloadAction<{ eventId: string; sessionId: string }>) => {
      const event = state.events.find(e => e.id === action.payload.eventId);
      if (event && event.sessions) {
        event.sessions = event.sessions.filter(s => s.id !== action.payload.sessionId);
        localStorage.setItem('linqora_events', JSON.stringify(state.events));
      }
    }
  },
});

export const { addEvent, updateEvent, deleteEvent, addSession, updateSession, deleteSession } = eventSlice.actions;
export default eventSlice.reducer;