import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { RootState } from '@/store';
import { motion } from 'framer-motion';
import { 
  Calendar, 
  MapPin, 
  ArrowRight, 
  Share2, 
  CheckCircle2, 
  MessageCircle,
  Settings 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import RegistrationDialog from '@/components/events/RegistrationDialog';
import ContactModal from '@/components/modals/ContactModal';
import { toast } from 'sonner';

const PublicEvent = () => {
  const { id } = useParams();
  const { events } = useSelector((state: RootState) => state.events);
  const event = events.find(e => e.id === id);

  const [isRegOpen, setIsRegOpen] = useState(false);
  const [isContactOpen, setIsContactOpen] = useState(false);

  if (!event) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Événement non trouvé</h2>
          <p className="text-slate-500 mb-4">Cet événement n'existe pas ou a été supprimé.</p>
          <Button onClick={() => window.history.back()} variant="outline">
            Retour
          </Button>
        </div>
      </div>
    );
  }

  const handleShare = async () => {
    const shareData = {
      title: event.title,
      text: `Rejoignez-moi à l'événement ${event.title} !`,
      url: window.location.href,
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(shareData.url);
        toast.success("Lien copié dans le presse-papier !");
      }
    } catch (err) {
      console.error('Erreur lors du partage:', err);
      toast.error("Partage non disponible. Lien copié dans le presse-papier.");
      try {
        await navigator.clipboard.writeText(shareData.url);
      } catch (clipboardErr) {
        toast.error("Impossible de copier le lien.");
      }
    }
  };

  const handleContact = () => {
    setIsContactOpen(true);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div className="relative h-[60vh] overflow-hidden">
        <img src={event.image} alt={event.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/40" />
        <div className="absolute inset-0 flex items-center justify-center text-center p-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-4xl text-white">
            <Badge className="mb-4 bg-primary text-white border-none px-4 py-1 rounded-full">
              {event.type}
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">{event.title}</h1>
            <div className="flex flex-wrap justify-center gap-6 text-lg font-medium">
              <span className="flex items-center gap-2">
                <Calendar size={20} /> 
                {new Date(event.date).toLocaleDateString('fr-FR', { 
                  day: 'numeric', 
                  month: 'long', 
                  year: 'numeric' 
                })}
              </span>
              <span className="flex items-center gap-2">
                <MapPin size={20} /> {event.location}
              </span>
            </div>
          </motion.div>
        </div>
      </div>

      {/* About Section */}
      <div className="container mx-auto px-4 -mt-10 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8 pb-20">
            <Card className="border-none shadow-xl rounded-[2rem] p-8 md:p-12 glass">
              <h2 className="text-2xl font-bold mb-6">À propos de l'événement</h2>
              <p className="text-slate-600 text-lg leading-relaxed whitespace-pre-line">
                {event.description || "Aucune description disponible pour cet événement."}
              </p>
            </Card>
          </div>
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <Card className="border-none shadow-2xl rounded-[2rem] overflow-hidden glass">
                <div className="gradient-primary p-8 text-white text-center">
                  <p className="text-white/80 font-medium mb-1">Accès Standard</p>
                  <h3 className="text-4xl font-bold">Gratuit</h3>
                </div>
                <CardContent className="p-8 space-y-6">
                  <ul className="space-y-3">
                    {["Accès aux conférences", "Networking", "Badge digital"].map((feat, i) => (
                      <li key={i} className="flex items-center gap-2 text-slate-600">
                        <CheckCircle2 className="text-emerald-500" size={18} /> {feat}
                      </li>
                    ))}
                  </ul>
                  <Button 
                    onClick={() => setIsRegOpen(true)} 
                    className="w-full btn-primary h-14 rounded-xl text-lg font-bold group"
                  >
                    S'inscrire maintenant <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      className="flex-1 rounded-xl" 
                      onClick={handleShare}
                    >
                      <Share2 className="mr-2" size={18} /> Partager
                    </Button>
                    <Button 
                      variant="outline" 
                      className="flex-1 rounded-xl" 
                      onClick={handleContact}
                    >
                      <MessageCircle className="mr-2" size={18} /> Contact
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* Sessions Section */}
      <div className="container mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold mb-8 text-center">Programme & Sessions</h2>
        {event.sessions && event.sessions.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {event.sessions.map((session, i) => (
              <motion.div 
                key={i} 
                initial={{ opacity: 0, y: 10 }} 
                animate={{ opacity: 1, y: 0 }} 
                transition={{ delay: i * 0.1 }}
              >
                <Card className="border-none shadow-xl rounded-[2rem] p-8 md:p-12 glass">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center gap-3">
                      <Calendar size={16} className="text-primary" />
                      <p className="text-sm text-slate-500">
                        {new Date(session.time).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <MapPin size={16} className="text-primary" />
                      <p className="text-sm text-slate-500">{session.room}</p>
                    </div>
                  </div>
                  <h3 className="text-xl font-bold mb-4">{session.title}</h3>
                  {session.speaker && (
                    <p className="text-sm text-primary font-medium mb-2">
                      Par {session.speaker}
                    </p>
                  )}
                  <p className="text-slate-500 text-sm">
                    {session.description || "Description non disponible"}
                  </p>
                  <Button variant="outline" className="w-full rounded-xl h-10 mt-4">
                    <Settings size={18} className="mr-2" /> Détails
                  </Button>
                </Card>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-10 text-slate-400">
            Aucune session programmée pour cet événement.
          </div>
        )}
      </div>

      {/* Sponsors Section */}
      <div className="container mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold mb-8 text-center">Sponsors</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8">
          {["Sponsor 1", "Sponsor 2", "Sponsor 3", "Sponsor 4"].map((sponsor, i) => (
            <motion.div 
              key={i} 
              initial={{ opacity: 0, y: 10 }} 
              animate={{ opacity: 1, y: 0 }} 
              transition={{ delay: i * 0.1 }}
            >
              <Card className="border-none shadow-xl rounded-[2rem] p-8 md:p-12 glass">
                <div className="h-40 bg-slate-100 rounded-xl flex items-center justify-center mb-4">
                  <span className="text-slate-400">Logo {sponsor}</span>
                </div>
                <h3 className="text-xl font-bold text-center">{sponsor}</h3>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* FAQ Section */}
      <div className="container mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold mb-8 text-center">FAQ</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            { q: "Comment s'inscrire ?", a: "Cliquez sur le bouton 'S'inscrire' et remplissez le formulaire." },
            { q: "Le networking est-il inclus ?", a: "Oui, tous les participants ont accès à l'espace networking." },
            { q: "Y a-t-il un code vestimentaire ?", a: "Tenue business casual recommandée." },
            { q: "Puis-je annuler mon inscription ?", a: "Oui, jusqu'à 48h avant l'événement." },
            { q: "Y aura-t-il de la restauration ?", a: "Des snacks et boissons seront servis pendant les pauses." },
            { q: "Comment contacter l'organisateur ?", a: "Utilisez le bouton 'Contact' sur cette page." }
          ].map((faq, i) => (
            <motion.div 
              key={i} 
              initial={{ opacity: 0, y: 10 }} 
              animate={{ opacity: 1, y: 0 }} 
              transition={{ delay: i * 0.1 }}
            >
              <Card className="border-none shadow-xl rounded-[2rem] p-8 md:p-12 glass">
                <h3 className="text-xl font-bold mb-4">{faq.q}</h3>
                <p className="text-slate-500">{faq.a}</p>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Registration Dialog */}
      <RegistrationDialog 
        isOpen={isRegOpen} 
        onClose={() => setIsRegOpen(false)} 
        eventTitle={event.title} 
      />

      {/* Contact Modal */}
      <ContactModal 
        isOpen={isContactOpen} 
        onClose={() => setIsContactOpen(false)} 
      />
    </div>
  );
};

export default PublicEvent;