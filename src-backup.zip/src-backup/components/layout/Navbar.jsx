import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Menu } from 'lucide-react';

const Navbar = () => {
  return (
    <nav className="fixed top-0 w-full z-50 glass border-b">
      <div className="container mx-auto px-4 h-20 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-10 h-10 gradient-primary rounded-xl flex items-center justify-center text-white font-bold text-xl">L</div>
          <span className="text-2xl font-bold text-gradient">LinQora</span>
        </Link>
        
        <div className="hidden md:flex items-center gap-8">
          <a href="#features" className="text-slate-600 hover:text-primary font-medium transition-colors">Fonctionnalités</a>
          <a href="#pricing" className="text-slate-600 hover:text-primary font-medium transition-colors">Tarifs</a>
          <Link to="/login">
            <Button variant="ghost" className="font-semibold">Connexion</Button>
          </Link>
          <Link to="/register">
            <Button className="btn-primary rounded-full px-8">Essai gratuit</Button>
          </Link>
        </div>

        <Button variant="ghost" size="icon" className="md:hidden">
          <Menu />
        </Button>
      </div>
    </nav>
  );
};

export default Navbar;