import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Users, QrCode, TrendingUp, Clock, ArrowLeft, Maximize2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip } from 'recharts';

const data = [
  { time: '09:00', count: 12 },
  { time: '09:15', count: 45 },
  { time: '09:30', count: 89 },
  { time: '09:45', count: 156 },
  { time: '10:00', count: 210 },
  { time: '10:15', count: 280 },
];

const LiveDashboard = () => {
  const [scans, setScans] = useState([
    { id: 1, name: "Alice Martin", time: "10:24:15", type: "VIP" },
    { id: 2, name: "Bob Durand", time: "10:23:50", type: "Standard" },
    { id: 3, name: "Charlie Leroy", time: "10:23:10", type: "Premium" },
  ]);

  // Simulation de nouveaux scans
  useEffect(() => {
    const interval = setInterval(() => {
      const names = ["Diane Petit", "Eric Morel", "Fanny Blanc", "Gilles Roux"];
      const newScan = {
        id: Date.now(),
        name: names[Math.floor(Math.random() * names.length)],
        time: new Date().toLocaleTimeString(),
        type: Math.random() > 0.7 ? "VIP" : "Standard"
      };
      setScans(prev => [newScan, ...prev].slice(0, 5));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-white p-8">
      <div className="flex items-center justify-between mb-12">
        <div className="flex items-center gap-4">
          <Link to="/dashboard">
            <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
              <ArrowLeft />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-black tracking-tighter">LIVE MONITORING</h1>
            <p className="text-slate-400 font-bold flex items-center gap-2">
              <span className="w-2 h-2 bg-red-500 rounded-full animate-ping" /> TECH SUMMIT 2024
            </p>
          </div>
        </div>
        <div className="flex gap-4">
          <div className="bg-white/5 px-6 py-3 rounded-2xl border border-white/10 text-center">
            <p className="text-xs text-slate-500 font-bold uppercase">Temps Réel</p>
            <p className="text-xl font-mono font-bold">10:25:42</p>
          </div>
          <Button variant="outline" className="rounded-2xl border-white/10 bg-white/5 text-white">
            <Maximize2 size={20} className="mr-2" /> Plein écran
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Stats Principales */}
        <div className="lg:col-span-2 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { label: "Présents", value: "312", total: "450", color: "text-blue-400", icon: Users },
              { label: "Scans / Heure", value: "124", total: "avg", color: "text-emerald-400", icon: QrCode },
              { label: "Engagement", value: "84%", total: "live", color: "text-violet-400", icon: TrendingUp }
            ].map((stat, i) => (
              <Card key={i} className="bg-white/5 border-white/10 rounded-[2.5rem] p-8">
                <div className="flex justify-between items-start mb-4">
                  <div className={`p-3 rounded-2xl bg-white/5 ${stat.color}`}>
                    <stat.icon size={24} />
                  </div>
                </div>
                <p className="text-slate-500 text-sm font-bold uppercase tracking-widest">{stat.label}</p>
                <h3 className={`text-5xl font-black mt-2 ${stat.color}`}>{stat.value}</h3>
              </Card>
            ))}
          </div>

          <Card className="bg-white/5 border-white/10 rounded-[2.5rem] p-8">
            <h3 className="text-xl font-bold mb-8">Flux d'entrées (15 min)</h3>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data}>
                  <defs>
                    <linearGradient id="colorLive" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#4361EE" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#4361EE" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="time" stroke="#475569" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis hide />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: 'none', borderRadius: '12px' }} />
                  <Area type="monotone" dataKey="count" stroke="#4361EE" strokeWidth={4} fill="url(#colorLive)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>

        {/* Derniers Scans */}
        <div className="space-y-6">
          <h3 className="text-xl font-bold flex items-center gap-2">
            <Clock className="text-primary" /> DERNIERS PASSAGES
          </h3>
          <div className="space-y-4">
            <AnimatePresence>
              {scans.map((scan) => (
                <motion.div
                  key={scan.id}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="bg-white/5 border border-white/10 p-6 rounded-3xl flex items-center justify-between"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-xl">
                      {scan.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-bold text-lg">{scan.name}</p>
                      <p className="text-xs text-slate-500 font-mono">{scan.time}</p>
                    </div>
                  </div>
                  <Badge className={scan.type === 'VIP' ? "bg-amber-500" : "bg-blue-500"}>
                    {scan.type}
                  </Badge>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LiveDashboard;