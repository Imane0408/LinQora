import * as React from "react"
import useEmblaCarousel, {
  type EmblaCarouselType,
  type EmblaOptionsType,
} from "embla-carousel-react"
import { ArrowLeft, ArrowRight } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

type CarouselApi = EmblaCarouselType | undefined

type UseCarouselParameters = {
  opts?: EmblaOptionsType
  api?: CarouselApi
}

type UseCarouselReturnType = {
  carouselApi: CarouselApi
  canScrollPrev: boolean
  canScrollNext: boolean
}

const useCarousel = ({ opts, api }: UseCarouselParameters): UseCarouselReturnType => {
  const [carouselApi, setCarouselApi] = React.useState<CarouselApi>(undefined)

  const onSelect = React.useCallback((api: EmblaCarouselType) => {
    if (!api) {
      return
    }

    // Update our state when the carousel scrolls
    // We need to force a re-render to update the buttons
    // eslint-disable-next-line react-hooks/exhaustive-deps
    setCarouselApi(api)
  }, [])

  const onInit = React.useCallback((api: EmblaCarouselType) => {
    onSelect(api)
  }, [onSelect])

  React.useEffect(() => {
    if (!api) {
      return
    }

    if (!opts) {
      api.on("reInit", onInit)
      api.on("select", onSelect)
    } else {
      api.on("reInit", onInit)
      api.on("select", onSelect)
    }

    return () => {
      if (!opts) {
        api.off("reInit", onInit)
        api.off("select", onSelect)
      } else {
        api.off("reInit", onInit)
        api.off("select", onSelect)
      }
    }
  }, [api, opts, onInit, onSelect])

  return {
    carouselApi,
    canScrollPrev: api?.canScrollPrev() ?? false,
    canScrollNext: api?.canScrollNext() ?? false,
  }
}

const Carousel = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, children, ...props }, ref) => {
  const { carouselApi } = useCarousel({})

  return (
    <div ref={ref} className={cn("relative", className)} {...props}>
      {children}
    </div>
  )
})
Carousel.displayName = "Carousel"

const CarouselContent = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => {
  const { carouselApi } = useCarousel({})

  return (
    <div ref={ref} className={cn("overflow-hidden", className)} {...props}>
      <div className="flex">{props.children}</div>
    </div>
  )
})
CarouselContent.displayName = "CarouselContent"

const CarouselItem = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => {
  return (
    <div
      ref={ref}
      className={cn("min-w-0 shrink-0 grow-0 basis-full", className)}
      {...props}
    />
  )
})
CarouselItem.displayName = "CarouselItem"

const CarouselPrevious = React.forwardRef<
  HTMLButtonElement,
  React.ComponentProps<typeof Button>
>(({ className, variant = "outline", size = "icon", ...props }, ref) => {
  const { carouselApi } = useCarousel({})

  return (
    <Button
      ref={ref}
      variant={variant}
      size={size}
      className={cn(
        "absolute left-1 top-1/2 -translate-y-1/2 z-10",
        className
      )}
      disabled={!carouselApi?.canScrollPrev()}
      onClick={() => carouselApi?.scrollPrev()}
      {...props}
    >
      <ArrowLeft className="h-4 w-4" />
      <span className="sr-only">Previous slide</span>
    </Button>
  )
})
CarouselPrevious.displayName = "CarouselPrevious"

const CarouselNext = React.forwardRef<
  HTMLButtonElement,
  React.ComponentProps<typeof Button>
>(({ className, variant = "outline", size = "icon", ...props }, ref) => {
  const { carouselApi } = useCarousel({})

  return (
    <Button
      ref={ref}
      variant={variant}
      size={size}
      className={cn(
        "absolute right-1 top-1/2 -translate-y-1/2 z-10",
        className
      )}
      disabled={!carouselApi?.canScrollNext()}
      onClick={() => carouselApi?.scrollNext()}
      {...props>
      <ArrowRight className="h-4 w-4" />
      <span className="sr-only">Next slide</span>
    </Button>
  )
})
CarouselNext.displayName = "CarouselNext"

export {
  type CarouselApi,
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselPrevious,
  CarouselNext,
  useCarousel,
}