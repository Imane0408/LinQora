import React from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter,
  DialogDescription
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

const DemoModal = ({ isOpen, onClose }) => {
  const handleSubmit = (e) => {
    e.preventDefault();
    toast.success("Demande envoyée ! Un conseiller LinQora vous contactera très prochainement.");
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[450px] rounded-[2rem] border-none shadow-2xl p-8">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">Réserver une démo</DialogTitle>
          <DialogDescription>
            Laissez-nous vos coordonnées et nous vous ferons découvrir la puissance de LinQora.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Nom complet</Label>
            <Input id="name" placeholder="Jean Dupont" className="h-12 rounded-xl" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email professionnel</Label>
            <Input id="email" type="email" placeholder="jean@entreprise.com" className="h-12 rounded-xl" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="company">Entreprise</Label>
            <Input id="company" placeholder="Nom de votre structure" className="h-12 rounded-xl" required />
          </div>
          <DialogFooter className="pt-4">
            <Button type="submit" className="w-full btn-primary h-12 rounded-xl font-bold">
              Envoyer ma demande
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default DemoModal;
＜/dyad-write>

Je continue avec les autres composants. Je vais maintenant faire les composants UI qui sont déjà en JavaScript, donc pas besoin de les convertir. Mais je dois vérifier que tous les fichiers .tsx et .ts sont convertis.

Je vais lister les fichiers restants à convertir :

- src/components/ui/*.tsx -> .jsx (mais ces fichiers sont des composants shadcn/ui, ils sont déjà en TypeScript. Je dois les convertir en JavaScript ? L'utilisateur a dit de convertir tout le projet. Donc oui, je dois les convertir aussi.

Cependant, les composants shadcn/ui sont nombreux. Je vais les convertir un par un. Mais attention, certains d'entre eux peuvent avoir des types. Je vais devoir supprimer les types.

Je vais commencer par les composants UI les plus simples.

Mais avant, je dois m'assurer que tous les fichiers de l'application sont convertis. Je vais faire une liste :

Fichiers déjà convertis (pages et composants principaux) :
- App.jsx
- Navbar.jsx
- DashboardLayout.jsx
- Login.jsx
- Register.jsx
- Dashboard.jsx
- Events.jsx
- EventDetails.jsx (corrigé)
- Participants.jsx
- Scan.jsx
- Networking.jsx
- Profile.jsx
- Settings.jsx
- Companies.jsx
- MyTickets.jsx
- PublicEvent.jsx
- History.jsx
- LiveDashboard.jsx

Fichiers de store et hooks :
- store/index.js
- store/slices/authSlice.js
- store/slices/eventSlice.js
- hooks/use-mobile.js
- lib/utils.js
- utils/export.js
- lib/store.js

Fichiers de composants :
- components/layout/Navbar.jsx (déjà fait)
- components/layout/DashboardLayout.jsx (déjà fait)
- components/events/AddSessionDialog.jsx
- components/events/BadgeDialog.jsx
- components/events/RegistrationDialog.jsx
- components/networking/ChatDialog.jsx
- components/networking/MeetingRequestDialog.jsx
- components/modals/ConfirmDialog.jsx
- components/modals/EmailDialog.jsx
- components/modals/DemoModal.jsx

Il reste les composants UI de shadcn/ui. Je vais les convertir maintenant.

Je vais prendre un exemple : button.tsx

<dyad-write path="src/components/ui/button.jsx" description="Conversion de button.tsx vers JavaScript">
import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive:
          "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        outline:
          "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
        secondary:
          "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-md px-3",
        lg: "h-11 rounded-md px-8",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

const Button = React.forwardRef(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }