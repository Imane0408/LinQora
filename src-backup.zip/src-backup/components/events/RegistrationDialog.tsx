import React, { useState } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CheckCircle2, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import confetti from 'canvas-confetti';

interface RegistrationDialogProps {
  isOpen: boolean;
  onClose: () => void;
  eventTitle: string;
}

const RegistrationDialog = ({ isOpen, onClose, eventTitle }: RegistrationDialogProps) => {
  const [step, setStep] = useState<'form' | 'success'>('form');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulation d'envoi
    setTimeout(() => {
      setIsLoading(false);
      setStep('success');
      confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#4361EE', '#7209B7', '#F72585']
      });
      toast.success('Inscription confirmée !');
    }, 1500);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] rounded-[2.5rem] border-none shadow-2xl p-0 overflow-hidden">
        {step === 'form' ? (
          <form onSubmit={handleSubmit}>
            <div className="p-8 space-y-6">
              <DialogHeader>
                <DialogTitle className="text-2xl font-bold">S'inscrire à l'événement</DialogTitle>
                <p className="text-slate-500">{eventTitle}</p>
              </DialogHeader>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Prénom</Label>
                    <Input placeholder="Jean" className="h-12 rounded-xl" required />
                  </div>
                  <div className="space-y-2">
                    <Label>Nom</Label>
                    <Input placeholder="Dupont" className="h-12 rounded-xl" required />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Email professionnel</Label>
                  <Input type="email" placeholder="jean@entreprise.com" className="h-12 rounded-xl" required />
                </div>
                <div className="space-y-2">
                  <Label>Entreprise / Organisation</Label>
                  <Input placeholder="Nom de votre structure" className="h-12 rounded-xl" required />
                </div>
                <div className="space-y-2">
                  <Label>Poste occupé</Label>
                  <Input placeholder="Ex: Directeur Marketing" className="h-12 rounded-xl" required />
                </div>
              </div>
            </div>

            <DialogFooter className="p-8 bg-slate-50 flex flex-col sm:flex-row gap-3">
              <Button type="button" variant="ghost" onClick={onClose} className="rounded-xl h-12 font-bold">Annuler</Button>
              <Button type="submit" disabled={isLoading} className="btn-primary flex-1 rounded-xl h-12 font-bold">
                {isLoading ? <Loader2 className="animate-spin mr-2" /> : null}
                Confirmer mon inscription
              </Button>
            </DialogFooter>
          </form>
        ) : (
          <div className="p-12 text-center space-y-6">
            <div className="w-20 h-20 gradient-primary rounded-full flex items-center justify-center text-white mx-auto shadow-xl">
              <CheckCircle2 size={40} />
            </div>
            <div className="space-y-2">
              <h2 className="text-3xl font-bold">C'est tout bon !</h2>
              <p className="text-slate-500">
                Votre place pour <strong>{eventTitle}</strong> est réservée. Un email de confirmation avec votre badge vient de vous être envoyé.
              </p>
            </div>
            <Button onClick={onClose} className="btn-primary w-full h-14 rounded-xl font-bold text-lg">
              Fermer
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default RegistrationDialog;