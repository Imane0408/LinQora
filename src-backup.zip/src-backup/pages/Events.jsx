import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Search, Filter, Calendar as CalendarIcon, MapPin, Users, MoreHorizontal, Trash2, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { deleteEvent } from '@/store/slices/eventSlice';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";

const Events = () => {
  const dispatch = useDispatch();
  const { events } = useSelector((state) => state.events);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [statusFilters, setStatusFilters] = useState([]);
  const [typeFilters, setTypeFilters] = useState([]);

  const toggleStatusFilter = (status) => {
    setStatusFilters(prev => 
      prev.includes(status) ? prev.filter(s => s !== status) : [...prev, status]
    );
  };

  const toggleTypeFilter = (type) => {
    setTypeFilters(prev => 
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  const resetFilters = () => {
    setStatusFilters([]);
    setTypeFilters([]);
    setSearchQuery('');
  };

  const filteredEvents = events.filter(event => {
    const matchesSearch = event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         event.location.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilters.length === 0 || statusFilters.includes(event.status);
    const matchesType = typeFilters.length === 0 || typeFilters.includes(event.type);

    return matchesSearch && matchesStatus && matchesType;
  });

  const handleDelete = (id, title) => {
    dispatch(deleteEvent(id));
    toast.error(`L'événement "${title}" a été supprimé.`);
  };

  const activeFiltersCount = statusFilters.length + typeFilters.length;

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Mes Événements</h1>
          <p className="text-slate-500">Gérez et suivez vos événements en cours.</p>
        </div>
        <Link to="/events/create">
          <Button className="btn-primary rounded-xl h-12 px-6">
            <Plus className="mr-2" size={20} />
            Créer un événement
          </Button>
        </Link>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <Input 
            placeholder="Rechercher un événement..." 
            className="pl-10 h-12 rounded-xl border-slate-200"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className={cn(
              "h-12 rounded-xl border-slate-200 relative",
              activeFiltersCount > 0 && "border-primary text-primary bg-primary/5"
            )}>
              <Filter className="mr-2" size={18} /> 
              Filtres
              {activeFiltersCount > 0 && (
                <span className="absolute -top-2 -right-2 w-5 h-5 bg-primary text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white">
                  {activeFiltersCount}
                </span>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80 p-6 rounded-[2rem] border-none shadow-2xl" align="end">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-lg">Filtrer par</h3>
                {(activeFiltersCount > 0 || searchQuery !== '') && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={resetFilters}
                    className="text-xs text-primary font-bold hover:bg-primary/5"
                  >
                    Réinitialiser
                  </Button>
                )}
              </div>

              <div className="space-y-4">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Statut</p>
                <div className="space-y-3">
                  {['Publié', 'Brouillon', 'Programmé'].map((status) => (
                    <div key={status} className="flex items-center space-x-3">
                      <Checkbox 
                        id={`status-${status}`} 
                        checked={statusFilters.includes(status)}
                        onCheckedChange={() => toggleStatusFilter(status)}
                        className="rounded-md border-slate-200 data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                      />
                      <Label htmlFor={`status-${status}`} className="text-sm font-medium cursor-pointer">
                        {status}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Type</p>
                <div className="space-y-3">
                  {['Présentiel', 'Hybride', 'Virtuel'].map((type) => (
                    <div key={type} className="flex items-center space-x-3">
                      <Checkbox 
                        id={`type-${type}`} 
                        checked={typeFilters.includes(type)}
                        onCheckedChange={() => toggleTypeFilter(type)}
                        className="rounded-md border-slate-200 data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                      />
                      <Label htmlFor={`type-${type}`} className="text-sm font-medium cursor-pointer">
                        {type}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </PopoverContent>
        </Popover>
      </div>

      {filteredEvents.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredEvents.map((event, i) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="border-none shadow-lg rounded-[2rem] overflow-hidden card-hover group">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={event.image} 
                    alt={event.title} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute top-4 right-4">
                    <Badge className={cn(
                      "rounded-full px-3 py-1 font-semibold text-white",
                      event.status === 'Publié' ? "bg-emerald-500" : 
                      event.status === 'Brouillon' ? "bg-slate-500" : "bg-blue-500"
                    )}>
                      {event.status}
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-xl font-bold line-clamp-1">{event.title}</h3>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="rounded-full">
                          <MoreHorizontal size={20} />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="rounded-xl border-none shadow-xl">
                        <DropdownMenuItem className="text-red-600 focus:text-red-600 cursor-pointer" onClick={() => handleDelete(event.id, event.title)}>
                          <Trash2 size={16} className="mr-2" /> Supprimer
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                  
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center text-slate-500 text-sm">
                      <CalendarIcon size={16} className="mr-2 text-primary" />
                      {new Date(event.date).toLocaleDateString('fr-FR')}
                    </div>
                    <div className="flex items-center text-slate-500 text-sm">
                      <MapPin size={16} className="mr-2 text-primary" />
                      {event.location}
                    </div>
                    <div className="flex items-center text-slate-500 text-sm">
                      <Users size={16} className="mr-2 text-primary" />
                      {event.participants} / {event.capacity} inscrits
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Link to={`/events/${event.id}`} className="flex-1">
                      <Button variant="outline" className="w-full rounded-xl">Gérer</Button>
                    </Link>
                    <Link to={`/e/${event.id}`} className="flex-1">
                      <Button className="w-full btn-primary rounded-xl">Voir Landing</Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-white rounded-[3rem] border-2 border-dashed border-slate-100">
          <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-300">
            <Search size={32} />
          </div>
          <h3 className="text-xl font-bold text-slate-400">Aucun événement trouvé</h3>
          <p className="text-slate-400 mb-6">Essayez de modifier vos filtres ou votre recherche.</p>
          <Button variant="outline" className="rounded-xl" onClick={resetFilters}>Réinitialiser les filtres</Button>
        </div>
      )}
    </div>
  );
};

export default Events;