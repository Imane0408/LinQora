import React, { useState } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Calendar, Clock, MapPin } from 'lucide-react';
import { toast } from 'sonner';

interface MeetingRequestDialogProps {
  isOpen: boolean;
  onClose: () => void;
  participant: {
    name: string;
    role: string;
  } | null;
}

const MeetingRequestDialog = ({ isOpen, onClose, participant }: MeetingRequestDialogProps) => {
  const [date, setDate] = useState('2024-05-15');
  const [time, setTime] = useState('14:00');

  const handleRequest = () => {
    toast.success(`Demande de rendez-vous envoyée à ${participant?.name} !`);
    onClose();
  };

  if (!participant) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[450px] rounded-[2rem] border-none shadow-2xl p-8">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">Demander un RDV</DialogTitle>
          <p className="text-slate-500">Proposez une rencontre à <span className="font-bold text-primary">{participant.name}</span></p>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="flex items-center gap-2"><Calendar size={14} /> Date</Label>
              <select 
                className="w-full h-12 rounded-xl border border-slate-100 bg-slate-50 px-4 outline-none focus:ring-2 focus:ring-primary/20"
                value={date}
                onChange={(e) => setDate(e.target.value)}
              >
                <option value="2024-05-15">15 Mai 2024</option>
                <option value="2024-05-16">16 Mai 2024</option>
                <option value="2024-05-17">17 Mai 2024</option>
              </select>
            </div>
            <div className="space-y-2">
              <Label className="flex items-center gap-2"><Clock size={14} /> Heure</Label>
              <select 
                className="w-full h-12 rounded-xl border border-slate-100 bg-slate-50 px-4 outline-none focus:ring-2 focus:ring-primary/20"
                value={time}
                onChange={(e) => setTime(e.target.value)}
              >
                <option value="10:00">10:00</option>
                <option value="11:00">11:00</option>
                <option value="14:00">14:00</option>
                <option value="15:00">15:00</option>
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2"><MapPin size={14} /> Lieu suggéré</Label>
            <div className="p-3 rounded-xl bg-primary/5 border border-primary/10 text-primary text-sm font-bold">
              Espace Networking - Zone A
            </div>
          </div>

          <div className="space-y-2">
            <Label>Message (Optionnel)</Label>
            <Textarea 
              placeholder="Bonjour, j'aimerais discuter de..." 
              className="min-h-[100px] rounded-xl border-slate-100 bg-slate-50"
            />
          </div>
        </div>

        <DialogFooter className="gap-3">
          <Button variant="ghost" onClick={onClose} className="rounded-xl h-12 font-bold">Annuler</Button>
          <Button onClick={handleRequest} className="btn-primary flex-1 rounded-xl h-12 font-bold">Envoyer l'invitation</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default MeetingRequestDialog;